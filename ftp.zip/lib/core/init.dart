import 'package:arosaina/core/injection.dart';
import 'package:arosaina/core/permission/i.permission.handler.dart';
import 'package:arosaina/core/permission/permission.handler.impl.dart';

class Init {
  static Future<void> execute() async {
    final permissionHandler = sl<IPermissionHandler>();

    // Request media permission
    if (!await permissionHandler.checkPermission(MediaPermissionStrategy())) {
      await permissionHandler.requestPermission(MediaPermissionStrategy());
    }
  }
}
