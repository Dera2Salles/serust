import 'package:arosaina/core/api_client.dart';
import 'package:arosaina/core/permission/i.permission.handler.dart';
import 'package:arosaina/core/permission/permission.handler.impl.dart';
import 'package:arosaina/engine/connection/ftp_datasource_impl.dart';
import 'package:arosaina/engine/connection/i_ftp_datasource.dart';
import 'package:arosaina/engine/models/user_model.dart';
import 'package:arosaina/engine/connection/i_ftp_client.dart';
import 'package:arosaina/engine/connection/ftp_client.dart';
import 'package:arosaina/engine/services/ai_service_impl.dart';
import 'package:arosaina/engine/connection/i_secure_local_datasource.dart';
import 'package:arosaina/engine/services/auth_service_impl.dart';
import 'package:arosaina/engine/services/db_service_impl.dart';
import 'package:arosaina/engine/services/interfaces/i_ai_service.dart';
import 'package:arosaina/engine/services/interfaces/i_auth_service.dart';
import 'package:arosaina/engine/services/interfaces/i_db_service.dart';
import 'package:arosaina/engine/services/interfaces/i_settings_service.dart';
import 'package:arosaina/engine/services/secure_local_datasource_impl.dart';
import 'package:arosaina/engine/services/settings_service_impl.dart';
import 'package:arosaina/engine/transfert/i.transfer.repository.dart';
import 'package:arosaina/engine/transfert/transfer.repository.impl.dart';
import 'package:arosaina/presentation/bloc/explorer/explorer_bloc.dart';
import 'package:arosaina/presentation/bloc/ai_chat/ai_chat_bloc.dart';
import 'package:arosaina/presentation/services/media_service.dart';
import 'package:get_it/get_it.dart';
import 'package:hive_flutter/hive_flutter.dart';

final sl = GetIt.instance;

Future<void> setupLocator() async {
  // ── Database & Settings ──────────────────────────────────────────────────
  final dbService = DbServiceImpl();
  Hive.registerAdapter(UserModelAdapter());
  await dbService.init();

  sl.registerSingleton<IDbService>(dbService);
  sl.registerLazySingleton<ISettingsService>(() => SettingsServiceImpl(sl()));

  // ── Permissions & Essentials ──────────────────────────────────────────────
  sl.registerLazySingleton<IPermissionHandler>(() => PermissionHandlerImpl());
  sl.registerLazySingleton<MediaService>(() => MediaService(sl()));

  sl.registerLazySingleton<ApiClient>(
    () => ApiClient(baseUrl: sl<ISettingsService>().apiBaseUrl),
  );

  sl.registerLazySingleton<ISecureLocalDatasource>(
    () => SecureLocalDatasourceImpl(),
  );

  // ── Network & Datasources ────────────────────────────────────────────────
  sl.registerLazySingleton<IFtpClient>(() {
    final uri = Uri.parse(sl<ApiClient>().baseUrl);
    return FtpClient(uri.host, port: uri.port.toInt() > 0 ? uri.port : 8080);
  });

  sl.registerLazySingleton<IFtpDataSource>(() => FtpDataSourceImpl(sl(), sl()));

  // ── Services ─────────────────────────────────────────────────────────────
  sl.registerLazySingleton<IAuthService>(
    () => AuthServiceImpl(sl(), sl(), sl()),
  );
  sl.registerLazySingleton<IAiService>(() => AiServiceImpl(sl(), sl()));

  sl.registerLazySingleton<ITransferRepository>(
    () => TransferRepositoryImpl(sl()),
  );

  // ── Blocs ────────────────────────────────────────────────────────────────
  sl.registerFactory(() => ExplorerBloc(sl()));
  sl.registerFactory(() => AiChatBloc(sl()));
}
