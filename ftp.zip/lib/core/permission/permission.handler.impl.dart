import 'package:arosaina/core/permission/i.permission.handler.dart';
import 'package:permission_handler/permission_handler.dart' as ph;

class PermissionHandlerImpl implements IPermissionHandler {
  @override
  Future<PermissionStatus> requestPermission(
    PermissionStrategy strategy,
  ) async {
    ph.PermissionStatus status;
    if (strategy is MediaPermissionStrategy) {
      // Request Manage External Storage for Android 11+
      if (await ph.Permission.manageExternalStorage.status.isDenied) {
        await ph.Permission.manageExternalStorage.request();
      }
      status = await ph.Permission.storage.request();
      status = await ph.Permission.storage.request();
    } else {
      throw UnsupportedError("Unknown permission strategy");
    }
    return _toPermissionStatus(status);
  }

  @override
  Future<bool> checkPermission(PermissionStrategy strategy) async {
    ph.PermissionStatus status;
    if (strategy is MediaPermissionStrategy) {
      status = await ph.Permission.storage.status;
    } else {
      throw UnsupportedError("Unknown permission strategy");
    }
    return status == ph.PermissionStatus.granted;
  }

  PermissionStatus _toPermissionStatus(ph.PermissionStatus status) {
    switch (status) {
      case ph.PermissionStatus.granted:
        return PermissionStatus.granted;
      case ph.PermissionStatus.denied:
        return PermissionStatus.denied;
      case ph.PermissionStatus.restricted:
        return PermissionStatus.restricted;
      case ph.PermissionStatus.permanentlyDenied:
        return PermissionStatus.permanentlyDenied;
      case ph.PermissionStatus.provisional:
        return PermissionStatus.granted; // Treat provisional as granted for now
      case ph.PermissionStatus.limited:
        return PermissionStatus.granted; // Treat limited as granted for now
    }
  }
}

class MediaPermissionStrategy implements PermissionStrategy {}
