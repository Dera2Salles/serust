import 'dart:io';
import 'received_transfer.dart';
import 'transfer_tree_node.dart';

abstract class ITransferRepository {
  Future<void> sendFile(
    File file, {
    required String receiverId,
    int? maxShareCount,
  });

  Future<void> shareFile(
    String path,
    String toUser,
    String perm, {
    int? reads,
    int? downloads,
    int? writes,
    bool? reshare,
    int? expires,
  });

  Future<List<String>> getShares();

  Future<List<ReceivedTransfer>> getReceivedTransfers();

  Future<void> downloadFile(String fileId, String fileName);

  Future<List<TransferTreeNode>> getTransferTree(String fileId);
}
