import 'dart:io';
import '../connection/i_ftp_datasource.dart';
import 'received_transfer.dart';
import 'transfer_tree_node.dart';
import 'i.transfer.repository.dart';

class TransferRepositoryImpl implements ITransferRepository {
  final IFtpDataSource _dataSource;

  TransferRepositoryImpl(this._dataSource);

  @override
  Future<void> shareFile(
    String path,
    String toUser,
    String perm, {
    int? reads,
    int? downloads,
    int? writes,
    bool? reshare,
    int? expires,
  }) async {
    final cmd = StringBuffer('SHARE $path $toUser $perm');
    if (reads != null) cmd.write(' reads=$reads');
    if (downloads != null) cmd.write(' downloads=$downloads');
    if (writes != null) cmd.write(' writes=$writes');
    if (reshare != null) cmd.write(' reshare=${reshare ? 1 : 0}');
    if (expires != null) cmd.write(' expires=$expires');
    
    await _dataSource.sendCommand(cmd.toString());
  }

  @override
  Future<List<String>> getShares() async {
    final res = await _dataSource.sendCommand('SHARES IN');
    if (!res.startsWith('211')) return [];

    // Parse response
    final lines = res.split('\n');
    return lines.where((line) => line.startsWith(' owner=')).toList();
  }

  @override
  Future<void> sendFile(
    File file, {
    required String receiverId,
    int? maxShareCount,
  }) async {
    await _dataSource.uploadFile(file);
  }

  @override
  Future<List<ReceivedTransfer>> getReceivedTransfers() async {
    // Basic implementation for now: parse SHARES IN response.
    final res = await _dataSource.sendCommand('SHARES IN');
    if (!res.startsWith('211')) return [];

    // For now, return an empty list or parse if logic is available
    return [];
  }

  @override
  Future<void> downloadFile(String fileId, String fileName) async {
    final savePath = '/storage/emulated/0/Download/$fileName';
    await _dataSource.downloadFile(fileName, savePath);
  }

  @override
  Future<List<TransferTreeNode>> getTransferTree(String fileId) async {
    return []; // Not supported naturally in basic FTP LIST
  }
}
