import 'dart:io';
import '../models/ftp_entry.dart';

abstract class IFtpDataSource {
  Future<void> connect();
  Future<void> disconnect();

  /// Executes a raw FTP command and returns the response line.
  Future<String> sendCommand(String command);

  /// Current server-side working directory path
  Future<String> currentDir();
  Future<void> changeDir(String path);
  Future<void> navigateUp();

  Future<List<FtpEntry>> listDirectory();
  Future<void> uploadFile(File file, {String? originalFileName});
  Future<void> downloadFile(String remoteFileName, String localPath);

  Future<void> mkdir(String name);
  Future<void> rmdir(String name);
  Future<void> deleteFile(String name);
  Future<void> rename(String from, String to);
  Future<int?> getFileSize(String name);
}
