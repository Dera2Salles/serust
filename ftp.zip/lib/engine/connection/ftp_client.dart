import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:arosaina/engine/connection/i_ftp_client.dart';

/// Low-level FTP client over a raw TCP socket.
///
/// Thread-safety: all public methods are serialized through [_mutex] so
/// concurrent calls from the bloc never interleave responses.
class FtpClient implements IFtpClient {
  @override
  final String host;
  @override
  final int port;

  // ── Control connection ───────────────────────────────────────────────────
  Socket? _controlSocket;
  StreamSubscription<Uint8List>? _controlSubscription;
  Future<void>? _activeConnect;

  // Raw byte accumulator — decoded line by line
  final List<int> _byteBuffer = [];

  // One completer per pending command (FIFO)
  final List<Completer<String>> _responseQueue = [];

  // Responses received but not yet requested by a caller
  final List<String> _pendingResponses = [];

  // Multi-line response state  (e.g. "211-...\r\n...\r\n211 End")
  String? _multilineCode;
  final StringBuffer _multilineBuffer = StringBuffer();

  // ── Mutex — prevents concurrent FTP commands ─────────────────────────────
  // We use a simple sequential queue: each operation waits for the previous.
  Future<void> _lastOp = Future.value();

  /// Runs [fn] exclusively — no two calls overlap on the control socket.
  Future<T> _exclusive<T>(Future<T> Function() fn) {
    final next = _lastOp.then((_) => fn());
    // swallow errors in the chain so a failure doesn't block future ops
    _lastOp = next.then((_) {}, onError: (_) {});
    return next;
  }

  // ── Timeouts ─────────────────────────────────────────────────────────────
  static const _cmdTimeout = Duration(seconds: 30);
  static const _dataTimeout = Duration(minutes: 10);
  static const _connectTimeout = Duration(seconds: 15);
  // Server does read_to_end before replying 226 — give it generous time.
  static const _storCompleteTimeout = Duration(minutes: 5);

  FtpClient(this.host, {this.port = 8080});

  @override
  bool get isConnected => _controlSocket != null;

  // ── Connection ────────────────────────────────────────────────────────────

  @override
  Future<void> connect() async {
    if (isConnected) return;
    if (_activeConnect != null) return _activeConnect;

    _activeConnect = _establishConnection();
    try {
      await _activeConnect;
    } finally {
      _activeConnect = null;
    }
  }

  Future<void> _establishConnection() async {
    _controlSocket = await Socket.connect(host, port, timeout: _connectTimeout);
    _controlSocket!.setOption(SocketOption.tcpNoDelay, true);

    _controlSubscription = _controlSocket!.listen(
      _onData,
      onError: _onError,
      onDone: _onDone,
      cancelOnError: true,
    );

    final welcome = await _waitForResponse().timeout(_cmdTimeout);
    if (!welcome.startsWith('220')) {
      throw Exception('Unexpected FTP banner: $welcome');
    }
  }

  Future<void> _performLogin(String user, String pass) async {
    final r1 = await sendCommand('USER $user');
    if (!r1.startsWith('331')) throw Exception('USER failed: $r1');
    final r2 = await sendCommand('PASS $pass');
    if (!r2.startsWith('230')) throw Exception('Login failed: $r2');
  }

  void _onData(List<int> data) {
    _byteBuffer.addAll(data);
    _processBuffer();
  }

  void _onError(Object e) {
    _cleanupSession();
    final copy = List<Completer<String>>.from(_responseQueue);
    _responseQueue.clear();
    for (final c in copy) {
      if (!c.isCompleted) c.completeError(e);
    }
  }

  void _onDone() {
    _cleanupSession();
    _onError(Exception('Control socket closed unexpectedly'));
  }

  void _cleanupSession() {
    _controlSubscription?.cancel();
    _controlSubscription = null;
    _controlSocket = null;
  }

  void _processBuffer() {
    while (true) {
      final nl = _byteBuffer.indexOf(0x0A);
      if (nl == -1) break;

      final lineBytes = _byteBuffer.sublist(0, nl);
      _byteBuffer.removeRange(0, nl + 1);

      final trimmed = (lineBytes.isNotEmpty && lineBytes.last == 0x0D)
          ? lineBytes.sublist(0, lineBytes.length - 1)
          : lineBytes;

      _handleLine(utf8.decode(trimmed, allowMalformed: true));
    }
  }

  void _handleLine(String line) {
    // Start or continue multi-line: "XYZ-..."
    if (line.length >= 4 && RegExp(r'^\d{3}-').hasMatch(line)) {
      final code = line.substring(0, 3);
      if (_multilineCode == null) {
        _multilineCode = code;
        _multilineBuffer.clear();
      }
      _multilineBuffer.writeln(line);
      return;
    }

    // End of multi-line: "XYZ <text>"  (same code, space after)
    if (_multilineCode != null &&
        line.length >= 3 &&
        line.startsWith(_multilineCode!) &&
        (line.length == 3 || line[3] == ' ')) {
      _multilineBuffer.writeln(line);
      final full = _multilineBuffer.toString().trim();
      _multilineCode = null;
      _multilineBuffer.clear();
      _deliver(full);
      return;
    }

    // Plain single-line: "XYZ ..."
    if (line.length >= 4 && RegExp(r'^\d{3} ').hasMatch(line)) {
      if (_multilineCode != null) {
        _multilineBuffer.writeln(line); // orphan inside block
      } else {
        _deliver(line);
      }
      return;
    }

    // Continuation inside multi-line (no code prefix)
    if (_multilineCode != null) {
      _multilineBuffer.writeln(line);
    }
  }

  void _deliver(String response) {
    if (_responseQueue.isNotEmpty) {
      final c = _responseQueue.removeAt(0);
      if (!c.isCompleted) c.complete(response);
    } else {
      // Buffer the response for future callers
      _pendingResponses.add(response);
    }
  }

  Future<String> _waitForResponse() {
    if (_pendingResponses.isNotEmpty) {
      return Future.value(_pendingResponses.removeAt(0));
    }
    final c = Completer<String>();
    _responseQueue.add(c);
    return c.future;
  }

  // ── Command layer — always exclusive ──────────────────────────────────────

  @override
  Future<String> sendCommand(String command) {
    return _exclusive(() async {
      if (_controlSocket == null) throw Exception('Not connected');
      _controlSocket!.write('$command\r\n');
      return await _waitForResponse().timeout(
        _cmdTimeout,
        onTimeout: () => throw TimeoutException(
          'No response to $command within ${_cmdTimeout.inSeconds}s',
        ),
      );
    });
  }

  // ── Login ─────────────────────────────────────────────────────────────────

  @override
  Future<void> login(String user, String pass) async {
    await _performLogin(user, pass);
  }

  // ── Passive mode (internal — called inside an exclusive block) ────────────

  /// Must be called from within an [_exclusive] block so that the PASV
  /// response is consumed before any other command is sent.
  Future<Socket> _openDataSocket() async {
    if (_controlSocket == null) throw Exception('Not connected');
    _controlSocket!.write('PASV\r\n');
    final res = await _waitForResponse().timeout(_cmdTimeout);
    if (!res.startsWith('227')) throw Exception('PASV failed: $res');

    final m = RegExp(
      r'\((\d+),(\d+),(\d+),(\d+),(\d+),(\d+)\)',
    ).firstMatch(res);
    if (m == null) throw Exception('Cannot parse PASV: $res');

    final dataPort = int.parse(m.group(5)!) * 256 + int.parse(m.group(6)!);

    // Robust PASV: many servers behind NAT advertise an unroutable IP.
    // We always connect to the same host as the control connection.
    return await Socket.connect(host, dataPort, timeout: _connectTimeout);
  }

  // ── Directory listing ─────────────────────────────────────────────────────

  @override
  Future<List<String>> listDirectory([String? path]) {
    return _exclusive(() async {
      if (_controlSocket == null) throw Exception('Not connected');

      // Open data channel BEFORE sending LIST
      final dataSocket = await _openDataSocket();

      final cmd = path != null ? 'LIST $path' : 'LIST';
      _controlSocket!.write('$cmd\r\n');
      final res = await _waitForResponse().timeout(_cmdTimeout);

      if (!res.startsWith('150') && !res.startsWith('125')) {
        await _safeClose(dataSocket);
        throw Exception('LIST rejected: $res');
      }

      // Collect data with a timeout
      final buffer = BytesBuilder();
      await dataSocket
          .timeout(_dataTimeout, onTimeout: (s) => s.close())
          .forEach(buffer.add);
      await _safeClose(dataSocket);

      // Wait for 226 Transfer complete
      final done = await _waitForResponse().timeout(_cmdTimeout);
      if (!done.startsWith('226')) {
        throw Exception('LIST did not complete: $done');
      }

      return utf8
          .decode(buffer.toBytes(), allowMalformed: true)
          .split('\n')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
    });
  }

  // ── Upload ────────────────────────────────────────────────────────────────

  @override
  Future<void> uploadFile(
    String remoteName,
    File localFile, {
    void Function(int sent, int total)? onProgress,
  }) {
    return _exclusive(() async {
      if (_controlSocket == null) throw Exception('Not connected');

      final dataSocket = await _openDataSocket();

      _controlSocket!.write('STOR $remoteName\r\n');
      final res = await _waitForResponse().timeout(_cmdTimeout);

      if (!res.startsWith('150') && !res.startsWith('125')) {
        await _safeClose(dataSocket);
        throw Exception('STOR rejected: $res');
      }

      final total = await localFile.length();
      int sent = 0;
      await for (final chunk in localFile.openRead()) {
        dataSocket.add(chunk);
        sent += chunk.length;
        onProgress?.call(sent, total);
      }
      await dataSocket.flush();
      await _safeClose(dataSocket);

      // Server does read_to_end before sending 226 — wait generously.
      final done = await _waitForResponse().timeout(_storCompleteTimeout);
      if (!done.startsWith('226')) {
        throw Exception('STOR did not complete: $done');
      }
    });
  }

  // ── Download ──────────────────────────────────────────────────────────────

  @override
  Future<void> downloadFile(
    String remoteName,
    String localPath, {
    void Function(int received, int total)? onProgress,
  }) {
    return _exclusive(() async {
      if (_controlSocket == null) throw Exception('Not connected');

      final dataSocket = await _openDataSocket();

      _controlSocket!.write('RETR $remoteName\r\n');
      final res = await _waitForResponse().timeout(_cmdTimeout);

      if (!res.startsWith('150') && !res.startsWith('125')) {
        await _safeClose(dataSocket);
        throw Exception('RETR rejected: $res');
      }

      // Parse optional size hint from "150 Opening ... (1234 bytes)."
      int total = 0;
      final sm = RegExp(r'\((\d+) bytes\)').firstMatch(res);
      if (sm != null) total = int.parse(sm.group(1)!);

      final outFile = File(localPath);
      final sink = outFile.openWrite();
      int received = 0;

      try {
        await dataSocket
            .timeout(_dataTimeout, onTimeout: (s) => s.close())
            .forEach((chunk) {
              sink.add(chunk);
              received += chunk.length;
              if (total > 0) onProgress?.call(received, total);
            });
      } finally {
        await sink.flush();
        await sink.close();
        await _safeClose(dataSocket);
      }

      final done = await _waitForResponse().timeout(_cmdTimeout);
      if (!done.startsWith('226')) {
        throw Exception('RETR did not complete: $done');
      }
    });
  }

  // ── Navigation ────────────────────────────────────────────────────────────

  @override
  Future<String> pwd() async {
    final res = await sendCommand('PWD');
    return RegExp(r'"([^"]*)"').firstMatch(res)?.group(1) ?? '/';
  }

  @override
  Future<void> cwd(String path) async {
    final res = await sendCommand('CWD $path');
    if (!res.startsWith('250')) throw Exception('CWD failed: $res');
  }

  @override
  Future<void> cdup() async {
    final res = await sendCommand('CDUP');
    if (!res.startsWith('200') && !res.startsWith('250')) {
      throw Exception('CDUP failed: $res');
    }
  }

  // ── File management ───────────────────────────────────────────────────────

  @override
  Future<void> mkdir(String name) async {
    final res = await sendCommand('MKD $name');
    if (!res.startsWith('257')) throw Exception('MKD failed: $res');
  }

  @override
  Future<void> rmdir(String name) async {
    final res = await sendCommand('RMD $name');
    if (!res.startsWith('250')) throw Exception('RMD failed: $res');
  }

  @override
  Future<void> deleteFile(String name) async {
    final res = await sendCommand('DELE $name');
    if (!res.startsWith('250')) throw Exception('DELE failed: $res');
  }

  @override
  Future<void> rename(String from, String to) async {
    final r1 = await sendCommand('RNFR $from');
    if (!r1.startsWith('350')) throw Exception('RNFR failed: $r1');
    final r2 = await sendCommand('RNTO $to');
    if (!r2.startsWith('250')) throw Exception('RNTO failed: $r2');
  }

  @override
  Future<int?> size(String filename) async {
    final res = await sendCommand('SIZE $filename');
    if (res.startsWith('213')) return int.tryParse(res.substring(4).trim());
    return null;
  }

  @override
  Future<void> noop() async {
    final res = await sendCommand('NOOP');
    if (!res.startsWith('200')) throw Exception('NOOP failed: $res');
  }

  // ── Disconnect ────────────────────────────────────────────────────────────

  @override
  Future<void> disconnect() async {
    if (_controlSocket != null) {
      try {
        _controlSocket!.write('QUIT\r\n');
        await Future<void>.delayed(const Duration(milliseconds: 300));
      } catch (_) {}
      await _controlSubscription?.cancel();
      await _safeClose(_controlSocket!);
      _controlSocket = null;
    }
    // Drain any pending completers
    final copy = List<Completer<String>>.from(_responseQueue);
    _responseQueue.clear();
    for (final c in copy) {
      if (!c.isCompleted) {
        c.completeError(Exception('Disconnected'));
      }
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  Future<void> _safeClose(dynamic socket) async {
    try {
      await socket.close();
    } catch (_) {}
  }
}
