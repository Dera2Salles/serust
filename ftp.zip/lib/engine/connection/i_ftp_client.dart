// lib/engine/connection/i_ftp_client.dart

import 'dart:io';

abstract class IFtpClient {
  String get host;
  int get port;

  Future<void> connect();
  Future<void> disconnect();
  bool get isConnected;
  Future<void> login(String user, String pass);
  Future<String> sendCommand(String command);

  // Directory listing & Navigation
  Future<List<String>> listDirectory([String? path]);
  Future<String> pwd();
  Future<void> cwd(String path);
  Future<void> cdup();

  // File management
  Future<void> mkdir(String name);
  Future<void> rmdir(String name);
  Future<void> deleteFile(String name);
  Future<void> rename(String from, String to);
  Future<int?> size(String filename);
  Future<void> noop();

  // Transfers
  Future<void> uploadFile(
    String remoteName,
    File localFile, {
    void Function(int sent, int total)? onProgress,
  });

  Future<void> downloadFile(
    String remoteName,
    String localPath, {
    void Function(int received, int total)? onProgress,
  });
}
