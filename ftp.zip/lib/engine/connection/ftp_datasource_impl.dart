import 'dart:async';
import 'dart:io';

import 'dart:convert';
import 'package:arosaina/engine/connection/i_ftp_client.dart';
import 'package:arosaina/engine/connection/i_secure_local_datasource.dart';
import 'package:flutter/foundation.dart';
import '../models/ftp_entry.dart';
import 'i_ftp_datasource.dart';

class FtpDataSourceImpl implements IFtpDataSource {
  final IFtpClient _ftpClient;
  final ISecureLocalDatasource _secureLocalDatasource;

  FtpDataSourceImpl(this._ftpClient, this._secureLocalDatasource);

  @override
  Future<void> connect() async {
    // If already connected, we don't do anything (session is alive)
    if (_ftpClient.isConnected) return;

    try {
      await _ftpClient.connect();

      // Load saved credentials and re-authenticate
      final token = await _secureLocalDatasource.getToken();
      if (token != null) {
        final creds = jsonDecode(token) as Map<String, dynamic>;
        final user = creds['username'] as String;
        final pass = creds['password'] as String;
        await _ftpClient.login(user, pass);
      }
    } catch (e) {
      debugPrint('FTP Connect error: $e');
      rethrow;
    }
  }

  @override
  Future<void> disconnect() async {
    await _ftpClient.disconnect();
  }

  @override
  Future<String> sendCommand(String command) async {
    return await _ftpClient.sendCommand(command);
  }

  @override
  Future<String> currentDir() async {
    return await _ftpClient.pwd();
  }

  @override
  Future<void> changeDir(String path) async {
    await _ftpClient.cwd(path);
  }

  @override
  Future<void> navigateUp() async {
    await _ftpClient.cdup();
  }

  // ── Directory listing ────────────────────────────────────────────────────

  @override
  Future<List<FtpEntry>> listDirectory() async {
    try {
      final raw = await _ftpClient.listDirectory();
      final entries = <FtpEntry>[];
      for (final line in raw) {
        if (line.trim().isEmpty) continue;
        try {
          entries.add(FtpEntry.fromListLine(line));
        } catch (e) {
          debugPrint('Failed to parse LIST line: "$line" → $e');
        }
      }
      return entries;
    } catch (e) {
      debugPrint('listDirectory error: $e');
      return [];
    }
  }

  // ── CRUD ─────────────────────────────────────────────────────────────────

  @override
  Future<void> mkdir(String name) async {
    await _ftpClient.mkdir(name);
  }

  @override
  Future<void> rmdir(String name) async {
    await _ftpClient.rmdir(name);
  }

  @override
  Future<void> deleteFile(String name) async {
    await _ftpClient.deleteFile(name);
  }

  @override
  Future<void> rename(String from, String to) async {
    await _ftpClient.rename(from, to);
  }

  @override
  Future<int?> getFileSize(String name) async {
    return await _ftpClient.size(name);
  }

  // ── Transfers ────────────────────────────────────────────────────────────

  @override
  Future<void> uploadFile(File file, {String? originalFileName}) async {
    final fileName = originalFileName ?? file.path.split('/').last;

    try {
      await _ftpClient.uploadFile(fileName, file);
    } catch (e) {
      debugPrint('FTP upload error: $e');
      rethrow;
    }
  }

  @override
  Future<void> downloadFile(String remoteFileName, String localPath) async {
    try {
      await _ftpClient.downloadFile(remoteFileName, localPath);
    } catch (e) {
      debugPrint('FTP download error: $e');
      rethrow;
    }
  }

  Future<void> dispose() async {
    await _ftpClient.disconnect();
  }
}
