// lib/engine/services/interfaces/i_ai_service.dart

import 'package:arosaina/engine/models/ai_message.dart';

abstract class IAiService {
  /// Sends a message and returns the model response.
  /// [text] is the user's latest message.
  /// [history] is the conversation history including the user's latest message as the last item.
  Future<String> sendMessage(String text, List<AiMessage> history);
}
