import 'package:hive/hive.dart';
import '../../models/user_model.dart';

abstract class IDbService {
  Future<void> init();
  Box<UserModel> get userBox;
  Box get settingsBox;
}
