// lib/engine/services/ai_service_impl.dart

import 'dart:convert';
import 'package:arosaina/core/api_client.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:arosaina/engine/models/ai_message.dart';
import 'package:arosaina/engine/services/interfaces/i_ai_service.dart';
import 'package:arosaina/engine/services/interfaces/i_auth_service.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class AiServiceImpl implements IAiService {
  final ApiClient _apiClient;
  final IAuthService _authService;

  static const _kAiApiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent';
  static const _kMaxTokens = 2048;
  // TODO: Move this to a secure environment variable or settings
  static String get _kAiApiKey => dotenv.env['GEMINI_API_KEY'] ?? 'YOUR_GEMINI_API_KEY';

  String? _mcpSystemPrompt;
  String? _mcpResourceContext;

  AiServiceImpl(this._apiClient, this._authService);

  String get _username => _authService.getCurrentUser()?.username ?? 'user';

  String get _mcpBaseUrl {
    final uri = Uri.parse(_apiClient.baseUrl);
    return 'http://${uri.host}:8081/mcp';
  }

  @override
  Future<String> sendMessage(String text, List<AiMessage> history) async {
    await _fetchMcpContext();

    // Fetch available tools
    final tools = await _fetchMcpTools();

    List<Map<String, dynamic>> contents = history
        .map((m) => m.toGeminiJson())
        .toList();
    String finalText = '';

    // Agentic loop: handle function calls
    for (int iteration = 0; iteration < 10; iteration++) {
      final body = {
        'contents': contents,
        if (tools.isNotEmpty)
          'tools': [
            {'function_declarations': tools},
          ],
        'system_instruction': {
          'parts': [
            {'text': _buildSystemPrompt()},
          ],
        },
        'generationConfig': {
          'maxOutputTokens': _kMaxTokens,
          'temperature': 0.1,
        },
      };

      final resp = await http.post(
        Uri.parse('$_kAiApiUrl?key=$_kAiApiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (resp.statusCode != 200) {
        throw Exception('AI API error ${resp.statusCode}: ${resp.body}');
      }

      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final candidate = data['candidates']?[0] as Map<String, dynamic>?;
      if (candidate == null) throw Exception('No response from AI');

      final content = candidate['content'] as Map<String, dynamic>?;
      final parts = content?['parts'] as List<dynamic>? ?? [];

      // Update history with the model's response
      contents.add({'role': 'model', 'parts': parts});

      // Extract text
      final textParts = parts
          .where((p) => p.containsKey('text'))
          .map((p) => p['text'] as String)
          .join('\n');
      if (textParts.isNotEmpty) finalText = textParts;

      // Check for function calls
      final functionCalls = parts
          .where((p) => p.containsKey('functionCall'))
          .toList();
      if (functionCalls.isEmpty) break;

      // Execute function calls
      final responses = <Map<String, dynamic>>[];
      for (final callPart in functionCalls) {
        final call = callPart['functionCall'] as Map<String, dynamic>;
        final name = call['name'] as String;
        final args = Map<String, dynamic>.from(call['args'] as Map? ?? {});

        // Inject username automatically
        args['username'] = _username;

        final result = await _callMcpTool(name, args);
        responses.add({
          'functionResponse': {
            'name': name,
            'response': {'content': result},
          },
        });
      }

      // Add function responses to history
      contents.add({'role': 'user', 'parts': responses});
    }

    return finalText.isNotEmpty ? finalText : 'I have processed your request.';
  }

  // ── MCP helpers ───────────────────────────────────────────────────────────

  Future<void> _fetchMcpContext() async {
    try {
      // 1. Fetch storage analysis prompt
      final promptResp = await http
          .post(
            Uri.parse(_mcpBaseUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'jsonrpc': '2.0',
              'id': 100,
              'method': 'prompts/get',
              'params': {
                'name': 'analyze_storage',
                'arguments': {'username': _username},
              },
            }),
          )
          .timeout(const Duration(seconds: 5));

      if (promptResp.statusCode == 200) {
        final data = jsonDecode(promptResp.body);
        final messages = data['result']?['messages'] as List<dynamic>?;
        if (messages != null && messages.isNotEmpty) {
          _mcpSystemPrompt = messages[0]['content']?['text'] as String?;
        }
      }

      // 2. Fetch available resources (files)
      final resourceResp = await http
          .post(
            Uri.parse(_mcpBaseUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'jsonrpc': '2.0',
              'id': 101,
              'method': 'resources/list',
              'params': {'username': _username},
            }),
          )
          .timeout(const Duration(seconds: 5));

      if (resourceResp.statusCode == 200) {
        final data = jsonDecode(resourceResp.body);
        final resources = data['result']?['resources'] as List<dynamic>?;
        if (resources != null) {
          _mcpResourceContext = resources
              .map((r) => '- ${r['name']} (${r['uri']})')
              .join('\n');
        }
      }
    } catch (e) {
      debugPrint('MCP Context fetch error: $e');
    }
  }

  Future<List<Map<String, dynamic>>> _fetchMcpTools() async {
    try {
      final resp = await http
          .post(
            Uri.parse(_mcpBaseUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'jsonrpc': '2.0',
              'id': 1,
              'method': 'tools/list',
              'params': {},
            }),
          )
          .timeout(const Duration(seconds: 5));

      if (resp.statusCode != 200) return [];
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final result = data['result'] as Map<String, dynamic>?;
      final toolsList = result?['tools'] as List<dynamic>? ?? [];

      return toolsList.map((t) {
        final tool = t as Map<String, dynamic>;
        return {
          'name': tool['name'],
          'description': tool['description'],
          'parameters': _convertSchemaToAi(tool['input_schema']),
        };
      }).toList();
    } catch (_) {
      return [];
    }
  }

  Map<String, dynamic> _convertSchemaToAi(dynamic schema) {
    if (schema is! Map) return <String, dynamic>{};
    final result = Map<String, dynamic>.from(schema);

    // AI API expects standard OpenAPI type strings, usually uppercase
    if (result.containsKey('type') && result['type'] is String) {
      result['type'] = (result['type'] as String).toUpperCase();
    }

    // Remove unsupported keys
    result.remove('default');

    if (result.containsKey('properties') && result['properties'] is Map) {
      final props = result['properties'] as Map;
      final newProps = <String, dynamic>{};
      for (final entry in props.entries) {
        newProps[entry.key as String] = _convertSchemaToAi(entry.value);
      }
      result['properties'] = newProps;
    }

    if (result.containsKey('items') && result['items'] is Map) {
      result['items'] = _convertSchemaToAi(result['items']);
    }

    return result;
  }

  Future<String> _callMcpTool(
    String toolName,
    Map<String, dynamic> args,
  ) async {
    try {
      final resp = await http
          .post(
            Uri.parse(_mcpBaseUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'jsonrpc': '2.0',
              'id': 2,
              'method': 'tools/call',
              'params': {'name': toolName, 'arguments': args},
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (resp.statusCode != 200) {
        return 'Error: HTTP ${resp.statusCode}';
      }

      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      final result = data['result'] as Map<String, dynamic>?;
      final content = result?['content'] as List<dynamic>?;
      return content?.map((c) => c['text']).join('\n') ??
          'Success (no text output)';
    } catch (e) {
      return 'Tool error: $e';
    }
  }

  String _buildSystemPrompt() {
    final base =
        '''You are an AI assistant integrated into AroSaina, a personal FTP file storage app.
You help the user manage their files using the available tools.
The current user is "$_username".

Guidelines:
- Always inject the username "$_username" when calling tools (it's handled automatically).
- Be concise and friendly.
- When listing files, format the output clearly.
- Always confirm destructive actions (delete) before executing if the user hasn't explicitly confirmed.
- If a tool fails, explain what went wrong simply.
- Speak in the same language as the user.''';

    final mcpPrompt = _mcpSystemPrompt != null
        ? '\n\nSERVER-PROVIDED CONTEXT (Storage Analysis):\n$_mcpSystemPrompt'
        : '';

    final mcpResources = _mcpResourceContext != null
        ? '\n\nAVAILABLE FILE RESOURCES (Native URIs):\n$_mcpResourceContext'
        : '';

    return '$base$mcpPrompt$mcpResources';
  }
}
