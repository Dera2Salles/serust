// lib/engine/models/ai_message.dart

enum AiRole {
  user,
  model;

  String get value => name;

  static AiRole fromString(String value) {
    return AiRole.values.firstWhere(
      (e) => e.name == value,
      orElse: () => AiRole.user,
    );
  }
}

class AiMessage {
  final AiRole role;
  final String text;
  final bool isLoading;

  const AiMessage({
    required this.role,
    required this.text,
    this.isLoading = false,
  });

  Map<String, dynamic> toGeminiJson() {
    return {
      'role': role.name,
      'parts': [
        {'text': text},
      ],
    };
  }

  factory AiMessage.fromGeminiParts(AiRole role, List<dynamic> parts) {
    final text = parts
        .where((p) => p.containsKey('text'))
        .map((p) => p['text'] as String)
        .join('\n');
    return AiMessage(role: role, text: text);
  }
}
