// lib/presentation/bloc/ai_chat/ai_chat_bloc.dart

import 'package:arosaina/engine/models/ai_message.dart';
import 'package:arosaina/engine/services/interfaces/i_ai_service.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// ── Events ────────────────────────────────────────────────────────────────────

abstract class AiChatEvent {}

class AiChatStarted extends AiChatEvent {}

class AiChatMessageSent extends AiChatEvent {
  final String text;
  AiChatMessageSent(this.text);
}

class AiChatReset extends AiChatEvent {}

// ── State ─────────────────────────────────────────────────────────────────────

enum AiChatStatus { initial, loading, success, error }

class AiChatState {
  final AiChatStatus status;
  final List<AiMessage> messages;
  final String? errorMessage;

  const AiChatState({
    this.status = AiChatStatus.initial,
    this.messages = const [],
    this.errorMessage,
  });

  AiChatState copyWith({
    AiChatStatus? status,
    List<AiMessage>? messages,
    String? errorMessage,
  }) {
    return AiChatState(
      status: status ?? this.status,
      messages: messages ?? this.messages,
      errorMessage: errorMessage,
    );
  }
}

// ── Bloc ──────────────────────────────────────────────────────────────────────

class AiChatBloc extends Bloc<AiChatEvent, AiChatState> {
  final IAiService _aiService;

  AiChatBloc(this._aiService) : super(const AiChatState()) {
    on<AiChatStarted>(_onStarted);
    on<AiChatMessageSent>(_onMessageSent);
    on<AiChatReset>(_onReset);
  }

  void _onStarted(AiChatStarted event, Emitter<AiChatState> emit) {
    if (state.messages.isNotEmpty) return;

    const initialWelcome = AiMessage(
      role: AiRole.model,
      text:
          '👋 Hello! I am your Gemini assistant. I can help you manage your files. Try asking me:\n'
          '• "What files do I have?"\n'
          '• "How much storage am I using?"\n'
          '• "Find all my PDFs"\n'
          '• "Create a folder called Projects"\n'
          '• "Organize my photos folder"',
    );

    emit(
      state.copyWith(status: AiChatStatus.success, messages: [initialWelcome]),
    );
  }

  Future<void> _onMessageSent(
    AiChatMessageSent event,
    Emitter<AiChatState> emit,
  ) async {
    final text = event.text.trim();
    if (text.isEmpty) return;

    // 1. Add user message and loading model message
    final updatedMessages = List<AiMessage>.from(state.messages)
      ..add(AiMessage(role: AiRole.user, text: text))
      ..add(const AiMessage(role: AiRole.model, text: '', isLoading: true));

    emit(
      state.copyWith(status: AiChatStatus.loading, messages: updatedMessages),
    );

    try {
      // 2. Call AI Service
      // We pass the history including the new user message
      final historyForService = updatedMessages.sublist(
        0,
        updatedMessages.length - 1,
      );
      final reply = await _aiService.sendMessage(text, historyForService);

      // 3. Update state with real reply
      final finalMessages = List<AiMessage>.from(state.messages)
        ..removeLast() // remove loading
        ..add(AiMessage(role: AiRole.model, text: reply));

      emit(
        state.copyWith(status: AiChatStatus.success, messages: finalMessages),
      );
    } catch (e) {
      String errorMessage = 'Something went wrong. Please try again.';
      final eStr = e.toString();

      if (eStr.contains('429')) {
        errorMessage =
            'Assistant is currently busy due to high demand. Please wait a moment before trying again.';
      } else if (eStr.contains('400')) {
        errorMessage =
            'Bad Request: The AI service rejected your request. This may be due to an invalid model or tool configuration.';
        if (eStr.contains('Function calling is not enabled')) {
          errorMessage =
              'This AI model does not support file management tools. Please switch to a compatible model.';
        }
      } else if (eStr.contains('500') || eStr.contains('503')) {
        errorMessage =
            'The AI service is temporarily unavailable. Please try again later.';
      } else if (eStr.contains('401') || eStr.contains('403')) {
        errorMessage =
            'Authentication failed. Please check your API configuration.';
      } else {
        // Carry forward the actual error message for diagnostics
        errorMessage = 'Something went wrong: ${eStr.split('Exception: ').last}';
      }

      final errorMessages = List<AiMessage>.from(state.messages)
        ..removeLast() // remove loading
        ..add(AiMessage(role: AiRole.model, text: '⚠️ $errorMessage'));

      emit(
        state.copyWith(
          status: AiChatStatus.error,
          messages: errorMessages,
          errorMessage: errorMessage,
        ),
      );
    }
  }

  void _onReset(AiChatReset event, Emitter<AiChatState> emit) {
    emit(
      const AiChatState(
        status: AiChatStatus.success,
        messages: [
          AiMessage(
            role: AiRole.model,
            text: '🔄 Chat cleared. How can I help you?',
          ),
        ],
      ),
    );
  }
}
