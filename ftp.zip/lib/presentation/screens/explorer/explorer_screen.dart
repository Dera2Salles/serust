import 'package:arosaina/core/injection.dart';
import 'package:arosaina/engine/models/ftp_entry.dart';
import 'package:arosaina/presentation/bloc/explorer/explorer_bloc.dart';
import 'package:arosaina/presentation/theme/app_theme.dart';
import 'package:arosaina/presentation/widgets/share_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ExplorerScreen extends StatelessWidget {
  const ExplorerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => sl<ExplorerBloc>()..add(ExplorerNavigateTo('/')),
      child: const _ExplorerView(),
    );
  }
}

class _ExplorerView extends StatelessWidget {
  const _ExplorerView();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppTheme.notionBlack : Colors.white;
    final textPrimary = isDark ? Colors.white : AppTheme.notionBlack;
    final textSecondary = isDark
        ? AppTheme.notionTextSecondaryDark
        : AppTheme.notionTextSecondaryLight;
    final divider = isDark
        ? AppTheme.notionDividerDark
        : AppTheme.notionDividerLight;
    final primary = Theme.of(context).primaryColor;

    return BlocConsumer<ExplorerBloc, ExplorerState>(
      listener: (context, state) {
        if (state.successMessage != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                state.successMessage!,
                style: const TextStyle(color: Colors.white),
              ),
              backgroundColor: isDark
                  ? AppTheme.notionSurface
                  : AppTheme.notionBlack,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              duration: const Duration(seconds: 2),
            ),
          );
        }
        if (state.errorMessage != null &&
            state.status == ExplorerStatus.error) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                state.errorMessage!,
                style: const TextStyle(color: Colors.white),
              ),
              backgroundColor: Colors.red.shade700,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      },
      builder: (context, state) {
        final bloc = context.read<ExplorerBloc>();
        final isAtRoot = state.pathSegments.length <= 1;

        return PopScope(
          canPop: isAtRoot,
          onPopInvokedWithResult: (didPop, result) {
            if (didPop) return;
            bloc.add(ExplorerNavigateUp());
          },
          child: Scaffold(
            backgroundColor: bg,
            body: SafeArea(
              child: Column(
                children: [
                  // ── Header ────────────────────────────────────────────────────
                  _ExplorerHeader(
                    state: state,
                    isDark: isDark,
                    bg: bg,
                    textPrimary: textPrimary,
                    textSecondary: textSecondary,
                    divider: divider,
                    primary: primary,
                    isAtRoot: isAtRoot,
                    onNavigateUp: () => bloc.add(ExplorerNavigateUp()),
                    onBreadcrumbTap: (path) => bloc.add(ExplorerNavigateTo(path)),
                    onRefresh: () => bloc.add(ExplorerRefresh()),
                  ),

                  // ── Body ──────────────────────────────────────────────────────
                  Expanded(
                    child: _ExplorerBody(
                      state: state,
                      isDark: isDark,
                      textPrimary: textPrimary,
                      textSecondary: textSecondary,
                      divider: divider,
                      bloc: bloc,
                      onDelete: (entry) => _confirmDelete(
                        context,
                        bloc,
                        entry,
                        isDark,
                        textPrimary,
                        textSecondary,
                      ),
                      onShare: (entry) => ShareDialog.show(context, entry.name),
                    ),
                  ),
                ],
              ),
            ),
            floatingActionButton: _ExplorerFab(
              isDark: isDark,
              textPrimary: textPrimary,
              onUpload: () => bloc.add(ExplorerUploadFile()),
              onNewFolder: () => _showNewFolderDialog(
                context,
                bloc,
                isDark,
                textPrimary,
                textSecondary,
              ),
            ),
          ),
        );
      },
    );
  }

  void _confirmDelete(
    BuildContext context,
    ExplorerBloc bloc,
    FtpEntry entry,
    bool isDark,
    Color textPrimary,
    Color textSecondary,
  ) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? AppTheme.notionSurface : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Delete "${entry.name}"?',
          style: TextStyle(
            color: textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Text(
          entry.isDirectory
              ? 'This folder and all its contents will be permanently deleted.'
              : 'This file will be permanently deleted.',
          style: TextStyle(color: textSecondary, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: TextStyle(color: textSecondary)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              bloc.add(ExplorerDeleteEntry(entry));
            },
            child: const Text(
              'Delete',
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  void _showNewFolderDialog(
    BuildContext context,
    ExplorerBloc bloc,
    bool isDark,
    Color textPrimary,
    Color textSecondary,
  ) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? AppTheme.notionSurface : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'New Folder',
          style: TextStyle(
            color: textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: TextStyle(color: textPrimary, fontSize: 14),
          decoration: InputDecoration(
            hintText: 'Folder name',
            hintStyle: TextStyle(color: textSecondary),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: isDark
                    ? AppTheme.notionDividerDark
                    : AppTheme.notionDividerLight,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: isDark
                    ? AppTheme.notionDividerDark
                    : AppTheme.notionDividerLight,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: textPrimary, width: 1.5),
            ),
            fillColor: isDark ? AppTheme.notionBlack : AppTheme.neutral50,
            filled: true,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: TextStyle(color: textSecondary)),
          ),
          TextButton(
            onPressed: () {
              final name = controller.text.trim();
              if (name.isNotEmpty) {
                Navigator.pop(ctx);
                bloc.add(ExplorerCreateFolder(name));
              }
            },
            child: Text(
              'Create',
              style: TextStyle(color: textPrimary, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Header ────────────────────────────────────────────────────────────────────

class _ExplorerHeader extends StatelessWidget {
  final ExplorerState state;
  final bool isDark;
  final Color bg;
  final Color textPrimary;
  final Color textSecondary;
  final Color divider;
  final Color primary;
  final bool isAtRoot;
  final VoidCallback onNavigateUp;
  final void Function(String) onBreadcrumbTap;
  final VoidCallback onRefresh;

  const _ExplorerHeader({
    required this.state,
    required this.isDark,
    required this.bg,
    required this.textPrimary,
    required this.textSecondary,
    required this.divider,
    required this.primary,
    required this.isAtRoot,
    required this.onNavigateUp,
    required this.onBreadcrumbTap,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: bg,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title + refresh
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 16, 0),
            child: Row(
              children: [
                if (!isAtRoot)
                  GestureDetector(
                    onTap: onNavigateUp,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: Icon(
                        Icons.arrow_back_ios_new_rounded,
                        size: 18,
                        color: textPrimary,
                      ),
                    ),
                  ),
                Text(
                  'Explorer',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: textPrimary,
                    letterSpacing: -0.5,
                  ),
                ),
                const Spacer(),
                if (state.status == ExplorerStatus.loading)
                  SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: primary,
                    ),
                  )
                else
                  GestureDetector(
                    onTap: onRefresh,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isDark
                            ? AppTheme.notionSurface
                            : AppTheme.neutral100,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        Icons.refresh_rounded,
                        size: 18,
                        color: textSecondary,
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // Breadcrumb
          if (state.pathSegments.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
              child: _BreadcrumbBar(
                segments: state.pathSegments,
                onTap: onBreadcrumbTap,
                textPrimary: textPrimary,
                textSecondary: textSecondary,
                primary: primary,
              ),
            ),

          // Item count subtitle
          if (state.status == ExplorerStatus.loaded)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
              child: Text(
                '${state.entries.length} item${state.entries.length == 1 ? '' : 's'}',
                style: TextStyle(
                  fontSize: 12,
                  color: textSecondary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),

          const SizedBox(height: 12),
          Divider(height: 1, thickness: 1, color: divider),
        ],
      ),
    );
  }
}

// ── Body ──────────────────────────────────────────────────────────────────────

class _ExplorerBody extends StatelessWidget {
  final ExplorerState state;
  final bool isDark;
  final Color textPrimary;
  final Color textSecondary;
  final Color divider;
  final ExplorerBloc bloc;
  final void Function(FtpEntry) onDelete;
  final void Function(FtpEntry) onShare;

  const _ExplorerBody({
    required this.state,
    required this.isDark,
    required this.textPrimary,
    required this.textSecondary,
    required this.divider,
    required this.bloc,
    required this.onDelete,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    if (state.status == ExplorerStatus.loading ||
        state.status == ExplorerStatus.idle) {
      return Center(
        child: SizedBox(
          width: 22,
          height: 22,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            color: isDark ? Colors.white54 : AppTheme.neutral400,
          ),
        ),
      );
    }

    if (state.status == ExplorerStatus.error) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.wifi_off_rounded, color: textSecondary, size: 44),
              const SizedBox(height: 16),
              Text(
                state.errorMessage ?? 'Something went wrong',
                style: TextStyle(
                  color: textSecondary,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => bloc.add(ExplorerLoadDir(state.currentPath)),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: textPrimary,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    'Try again',
                    style: TextStyle(
                      color: isDark ? AppTheme.notionBlack : Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (state.status == ExplorerStatus.loaded && state.entries.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: AppTheme.folderYellowBg,
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(
                Icons.folder_open_rounded,
                color: AppTheme.folderYellow,
                size: 32,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              'This folder is empty',
              style: TextStyle(
                color: textSecondary,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Upload a file or create a folder',
              style: TextStyle(
                color: textSecondary.withValues(alpha: 0.6),
                fontSize: 13,
              ),
            ),
          ],
        ),
      );
    }

    // Separate folders and files
    final folders = state.entries.where((e) => e.isDirectory).toList();
    final files = state.entries.where((e) => !e.isDirectory).toList();

    return ListView(
      padding: const EdgeInsets.only(top: 8, bottom: 100),
      children: [
        if (folders.isNotEmpty) ...[
          _SectionLabel(
            label: 'FOLDERS',
            count: folders.length,
            textSecondary: textSecondary,
          ),
          ...folders.map(
            (entry) => _EntryTile(
              entry: entry,
              isDark: isDark,
              textPrimary: textPrimary,
              textSecondary: textSecondary,
              divider: divider,
              onTap: () {
                final path = state.currentPath == '/'
                    ? '/${entry.name}'
                    : '${state.currentPath}/${entry.name}';
                bloc.add(ExplorerNavigateTo(path));
              },
              onDelete: () => onDelete(entry),
              onShare: () => onShare(entry),
            ),
          ),
          if (files.isNotEmpty) const SizedBox(height: 8),
        ],
        if (files.isNotEmpty) ...[
          _SectionLabel(
            label: 'FILES',
            count: files.length,
            textSecondary: textSecondary,
          ),
          ...files.map(
            (entry) => _EntryTile(
              entry: entry,
              isDark: isDark,
              textPrimary: textPrimary,
              textSecondary: textSecondary,
              divider: divider,
              onTap: () => bloc.add(ExplorerDownloadFile(entry)),
              onDelete: () => onDelete(entry),
              onShare: () => onShare(entry),
            ),
          ),
        ],
      ],
    );
  }
}

// ── Section Label ─────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String label;
  final int count;
  final Color textSecondary;

  const _SectionLabel({
    required this.label,
    required this.count,
    required this.textSecondary,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 6),
      child: Row(
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.2,
              color: textSecondary,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
            decoration: BoxDecoration(
              color: textSecondary.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              '$count',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Breadcrumb ────────────────────────────────────────────────────────────────

class _BreadcrumbBar extends StatelessWidget {
  final List<String> segments;
  final void Function(String) onTap;
  final Color textPrimary;
  final Color textSecondary;
  final Color primary;

  const _BreadcrumbBar({
    required this.segments,
    required this.onTap,
    required this.textPrimary,
    required this.textSecondary,
    required this.primary,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (int i = 0; i < segments.length; i++) ...[
            if (i > 0)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Icon(
                  Icons.chevron_right_rounded,
                  size: 14,
                  color: textSecondary,
                ),
              ),
            GestureDetector(
              onTap: () {
                if (i < segments.length - 1) {
                  final String path = i == 0
                      ? '/'
                      : '/${segments.sublist(1, i + 1).join('/')}';
                  onTap(path);
                }
              },
              child: Text(
                segments[i],
                style: TextStyle(
                  color: i == segments.length - 1 ? primary : textSecondary,
                  fontWeight: i == segments.length - 1
                      ? FontWeight.w700
                      : FontWeight.w400,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ── Entry Tile ────────────────────────────────────────────────────────────────

class _EntryTile extends StatelessWidget {
  final FtpEntry entry;
  final bool isDark;
  final Color textPrimary;
  final Color textSecondary;
  final Color divider;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  final VoidCallback onShare;

  const _EntryTile({
    required this.entry,
    required this.isDark,
    required this.textPrimary,
    required this.textSecondary,
    required this.divider,
    required this.onTap,
    required this.onDelete,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: () => _showActions(context),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: divider, width: 0.5)),
        ),
        child: Row(
          children: [
            // Icon container
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: entry.isDirectory
                    ? AppTheme.folderYellowBg
                    : textSecondary.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(11),
              ),
              child: Icon(
                entry.isDirectory
                    ? Icons.folder_rounded
                    : _fileIcon(entry.name),
                size: 20,
                color: entry.isDirectory
                    ? AppTheme.folderYellow
                    : textSecondary,
              ),
            ),

            const SizedBox(width: 14),

            // Name + meta
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    entry.name,
                    style: TextStyle(
                      color: textPrimary,
                      fontSize: 14,
                      fontWeight: entry.isDirectory
                          ? FontWeight.w600
                          : FontWeight.w400,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (!entry.isDirectory && entry.size > 0)
                    Text(
                      _formatSize(entry.size),
                      style: TextStyle(
                        fontSize: 11,
                        color: textSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                ],
              ),
            ),

            // Trailing indicator
            GestureDetector(
              onTap: () => _showActions(context),
              child: Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Icon(
                  Icons.more_vert_rounded,
                  size: 18,
                  color: textSecondary,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showActions(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppTheme.notionSurface : Colors.white;

    showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            Container(
              margin: const EdgeInsets.only(top: 12, bottom: 8),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            // File info
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Theme.of(
                        context,
                      ).primaryColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      entry.isDirectory
                          ? Icons.folder_rounded
                          : _fileIcon(entry.name),
                      color: entry.isDirectory
                          ? AppTheme.folderYellow
                          : AppTheme.neutral500,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          entry.name,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: textPrimary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          entry.isDirectory
                              ? 'Folder'
                              : _formatSize(entry.size),
                          style: TextStyle(fontSize: 12, color: textSecondary),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            Divider(
              height: 1,
              color: isDark
                  ? AppTheme.notionDividerDark
                  : AppTheme.notionDividerLight,
            ),

            ListTile(
              leading: Icon(Icons.share_rounded, color: textPrimary, size: 20),
              title: Text(
                'Share',
                style: TextStyle(
                  color: textPrimary,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                onShare();
              },
            ),

            if (!entry.isDirectory)
              ListTile(
                leading: Icon(
                  Icons.download_rounded,
                  color: textPrimary,
                  size: 20,
                ),
                title: Text(
                  'Download',
                  style: TextStyle(
                    color: textPrimary,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  onTap();
                },
              ),

            ListTile(
              leading: const Icon(
                Icons.delete_outline_rounded,
                color: Colors.red,
                size: 20,
              ),
              title: const Text(
                'Delete',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                onDelete();
              },
            ),

            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  IconData _fileIcon(String name) {
    final ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
      case 'webp':
        return Icons.image_rounded;
      case 'mp4':
      case 'mov':
      case 'avi':
      case 'mkv':
        return Icons.video_file_rounded;
      case 'mp3':
      case 'wav':
      case 'ogg':
      case 'aac':
        return Icons.audio_file_rounded;
      case 'pdf':
        return Icons.picture_as_pdf_rounded;
      case 'txt':
      case 'md':
        return Icons.article_rounded;
      case 'zip':
      case 'tar':
      case 'gz':
      case 'rar':
        return Icons.folder_zip_rounded;
      default:
        return Icons.insert_drive_file_rounded;
    }
  }

  String _formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

// ── FAB ───────────────────────────────────────────────────────────────────────

class _ExplorerFab extends StatefulWidget {
  final bool isDark;
  final Color textPrimary;
  final VoidCallback onUpload;
  final VoidCallback onNewFolder;

  const _ExplorerFab({
    required this.isDark,
    required this.textPrimary,
    required this.onUpload,
    required this.onNewFolder,
  });

  @override
  State<_ExplorerFab> createState() => _ExplorerFabState();
}

class _ExplorerFabState extends State<_ExplorerFab>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  late final AnimationController _ctrl;
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _expanded = !_expanded);
    if (_expanded) {
      _ctrl.forward();
    } else {
      _ctrl.reverse();
    }
  }

  @override
  Widget build(BuildContext context) {
    final bg = widget.isDark ? Colors.white : AppTheme.notionBlack;
    final fg = widget.isDark ? AppTheme.notionBlack : Colors.white;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        FadeTransition(
          opacity: _fade,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _MiniAction(
                bg: bg,
                fg: fg,
                icon: Icons.upload_rounded,
                label: 'Upload File',
                onTap: () {
                  _toggle();
                  widget.onUpload();
                },
              ),
              const SizedBox(height: 10),
              _MiniAction(
                bg: bg,
                fg: fg,
                icon: Icons.create_new_folder_rounded,
                label: 'New Folder',
                onTap: () {
                  _toggle();
                  widget.onNewFolder();
                },
              ),
              const SizedBox(height: 14),
            ],
          ),
        ),
        FloatingActionButton(
          backgroundColor: bg,
          foregroundColor: fg,
          elevation: 2,
          onPressed: _toggle,
          child: AnimatedRotation(
            turns: _expanded ? 0.125 : 0,
            duration: const Duration(milliseconds: 200),
            child: const Icon(Icons.add, size: 26),
          ),
        ),
      ],
    );
  }
}

class _MiniAction extends StatelessWidget {
  final Color bg, fg;
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _MiniAction({
    required this.bg,
    required this.fg,
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: bg.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: bg,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Material(
            color: bg,
            borderRadius: BorderRadius.circular(28),
            child: SizedBox(
              width: 40,
              height: 40,
              child: Icon(icon, color: fg, size: 18),
            ),
          ),
        ],
      ),
    );
  }
}
