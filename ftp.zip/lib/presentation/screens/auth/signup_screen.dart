import 'package:arosaina/core/injection.dart';
import 'package:arosaina/engine/services/interfaces/i_auth_service.dart';
import 'package:arosaina/presentation/common/responsive.dart';
import 'package:arosaina/presentation/screens/home/home_screen.dart';
import 'package:arosaina/presentation/theme/app_theme.dart';
import 'package:arosaina/presentation/widgets/premium_components.dart';
import 'package:flutter/material.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _isLoading = false;
  bool _obscure = true;
  String? _error;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _signup() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      await sl<IAuthService>().register(
        _nameCtrl.text.trim(),
        _emailCtrl.text.trim(),
        _passCtrl.text,
      );
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const HomeScreen()),
          (_) => false,
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    } finally {
      if (mounted && _isLoading) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight;
    final textPrimary = isDark ? Colors.white : AppTheme.notionBlack;
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: context.rs(24),
            vertical: context.rs(20),
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Back button ──────────────────────────────────────────────
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: context.rs(40),
                    height: context.rs(40),
                    decoration: BoxDecoration(
                      color: isDark ? AppTheme.neutral800 : AppTheme.neutral100,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: border),
                    ),
                    child: Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 16,
                      color: textPrimary,
                    ),
                  ),
                ),

                SizedBox(height: context.rs(28)),

                // ── Headline ─────────────────────────────────────────────────
                Text(
                  'Create account',
                  style: TextStyle(
                    fontSize: context.rf(30),
                    fontWeight: FontWeight.w800,
                    letterSpacing: -1.0,
                    color: textPrimary,
                  ),
                ),
                SizedBox(height: context.rs(4)),
                Text(
                  'Join AroSaina — secure file transfer',
                  style: TextStyle(
                    fontSize: context.rf(14),
                    color: AppTheme.neutral500,
                    fontWeight: FontWeight.w400,
                  ),
                ),

                SizedBox(height: context.rs(32)),

                // ── Form card ─────────────────────────────────────────────────
                Container(
                  decoration: BoxDecoration(
                    color: isDark ? AppTheme.notionSurface : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: border),
                  ),
                  padding: EdgeInsets.all(context.rs(20)),
                  child: Column(
                    children: [
                      ModernTextField(
                        label: 'FULL NAME',
                        hintText: 'John Doe',
                        controller: _nameCtrl,
                        prefixIcon: Icons.person_outline_rounded,
                        validator: (v) =>
                            (v?.trim().isEmpty ?? true) ? 'Required' : null,
                      ),
                      SizedBox(height: context.rs(16)),
                      ModernTextField(
                        label: 'EMAIL',
                        hintText: 'you@example.com',
                        controller: _emailCtrl,
                        keyboardType: TextInputType.emailAddress,
                        prefixIcon: Icons.mail_outline_rounded,
                        validator: (v) =>
                            (v?.isEmpty ?? true) ? 'Required' : null,
                      ),
                      SizedBox(height: context.rs(16)),
                      ModernTextField(
                        label: 'PASSWORD',
                        hintText: '••••••••',
                        controller: _passCtrl,
                        obscureText: _obscure,
                        prefixIcon: Icons.lock_outline_rounded,
                        suffix: GestureDetector(
                          onTap: () => setState(() => _obscure = !_obscure),
                          child: Icon(
                            _obscure
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            color: AppTheme.neutral400,
                            size: 18,
                          ),
                        ),
                        validator: (v) => (v?.isEmpty ?? true)
                            ? 'Required'
                            : v!.length < 6
                            ? 'Min 6 characters'
                            : null,
                      ),
                    ],
                  ),
                ),

                // ── Error callout ─────────────────────────────────────────────
                if (_error != null) ...[
                  SizedBox(height: context.rs(12)),
                  Container(
                    padding: EdgeInsets.all(context.rs(12)),
                    decoration: BoxDecoration(
                      color: Colors.red.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.red.withValues(alpha: 0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.error_outline_rounded,
                          color: Colors.red,
                          size: 15,
                        ),
                        SizedBox(width: context.rs(8)),
                        Expanded(
                          child: Text(
                            _error!,
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: context.rf(12),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                SizedBox(height: context.rs(24)),

                // ── Primary CTA ───────────────────────────────────────────────
                GradientButton(
                  text: 'Create Account',
                  onPressed: _isLoading ? null : _signup,
                  isLoading: _isLoading,
                  icon: Icons.check_rounded,
                ),

                SizedBox(height: context.rs(12)),

                // ── Divider ───────────────────────────────────────────────────
                Row(
                  children: [
                    Expanded(child: Divider(color: border)),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: context.rs(12)),
                      child: Text(
                        'OR',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppTheme.neutral400,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ),
                    Expanded(child: Divider(color: border)),
                  ],
                ),

                SizedBox(height: context.rs(12)),

                // ── Back to login outline button ───────────────────────────────
                OutlineActionButton(
                  text: 'Already have an account? Sign in',
                  onPressed: () => Navigator.pop(context),
                  height: 48,
                ),

                SizedBox(height: context.rs(24)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
