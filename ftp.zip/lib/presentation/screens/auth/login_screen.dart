import 'package:arosaina/core/injection.dart';
import 'package:arosaina/engine/services/interfaces/i_auth_service.dart';
import 'package:arosaina/presentation/common/responsive.dart';
import 'package:arosaina/presentation/screens/auth/signup_screen.dart';
import 'package:arosaina/presentation/screens/home/home_screen.dart';
import 'package:arosaina/presentation/theme/app_theme.dart';
import 'package:arosaina/presentation/widgets/premium_components.dart';
import 'package:arosaina/presentation/widgets/server_config_dialog.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _loading = false;
  bool _obscure = true;
  String? _error;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final ok = await sl<IAuthService>().login(
        _emailCtrl.text,
        _passCtrl.text,
      );
      if (!mounted) return;
      if (ok) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const HomeScreen()),
        );
      } else {
        setState(() {
          _error = 'Invalid email or password';
          _loading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight;
    final textPrimary = isDark ? Colors.white : AppTheme.notionBlack;
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(
            horizontal: context.rs(24),
            vertical: context.rs(20),
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: context.rs(24)),

                // ── Brand row ───────────────────────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Logo chip
                    Container(
                      width: context.rs(50),
                      height: context.rs(50),
                      decoration: BoxDecoration(
                        color: textPrimary,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(
                        Icons.swap_horiz_rounded,
                        color: isDark ? AppTheme.notionBlack : Colors.white,
                        size: context.rs(26),
                      ),
                    ),
                    // Server config ghost button
                    _GhostIconButton(
                      icon: Icons.dns_rounded,
                      isDark: isDark,
                      onTap: () => ServerConfigDialog.show(context),
                    ),
                  ],
                ),

                SizedBox(height: context.rs(32)),

                // ── Headline ─────────────────────────────────────────────────
                Text(
                  'Welcome back',
                  style: TextStyle(
                    fontSize: context.rf(30),
                    fontWeight: FontWeight.w800,
                    letterSpacing: -1.0,
                    color: textPrimary,
                  ),
                ),
                SizedBox(height: context.rs(4)),
                Text(
                  'Sign in to your AroSaina account',
                  style: TextStyle(
                    fontSize: context.rf(14),
                    color: AppTheme.neutral500,
                    fontWeight: FontWeight.w400,
                  ),
                ),

                SizedBox(height: context.rs(36)),

                // ── Form card ─────────────────────────────────────────────────
                Container(
                  decoration: BoxDecoration(
                    color: isDark ? AppTheme.notionSurface : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: border),
                  ),
                  padding: EdgeInsets.all(context.rs(20)),
                  child: Column(
                    children: [
                      ModernTextField(
                        label: 'EMAIL',
                        hintText: 'you@example.com',
                        controller: _emailCtrl,
                        keyboardType: TextInputType.emailAddress,
                        prefixIcon: Icons.mail_outline_rounded,
                        validator: (v) =>
                            (v?.isEmpty ?? true) ? 'Required' : null,
                      ),
                      SizedBox(height: context.rs(16)),
                      ModernTextField(
                        label: 'PASSWORD',
                        hintText: '••••••••',
                        controller: _passCtrl,
                        obscureText: _obscure,
                        prefixIcon: Icons.lock_outline_rounded,
                        suffix: GestureDetector(
                          onTap: () => setState(() => _obscure = !_obscure),
                          child: Icon(
                            _obscure
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            color: AppTheme.neutral400,
                            size: 18,
                          ),
                        ),
                        validator: (v) =>
                            (v?.isEmpty ?? true) ? 'Required' : null,
                      ),
                    ],
                  ),
                ),

                // ── Error callout ─────────────────────────────────────────────
                if (_error != null) ...[
                  SizedBox(height: context.rs(12)),
                  Container(
                    padding: EdgeInsets.all(context.rs(12)),
                    decoration: BoxDecoration(
                      color: Colors.red.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.red.withValues(alpha: 0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.error_outline_rounded,
                          color: Colors.red,
                          size: 15,
                        ),
                        SizedBox(width: context.rs(8)),
                        Expanded(
                          child: Text(
                            _error!,
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: context.rf(12),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                SizedBox(height: context.rs(24)),

                // ── Primary CTA — shadcn PrimaryButton style ──────────────────
                GradientButton(
                  text: 'Sign In',
                  onPressed: _loading ? null : _login,
                  isLoading: _loading,
                ),

                SizedBox(height: context.rs(12)),

                // ── Divider with OR ───────────────────────────────────────────
                Row(
                  children: [
                    Expanded(child: Divider(color: border)),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: context.rs(12)),
                      child: Text(
                        'OR',
                        style: TextStyle(
                          fontSize: 11,
                          color: AppTheme.neutral400,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ),
                    Expanded(child: Divider(color: border)),
                  ],
                ),

                SizedBox(height: context.rs(12)),

                // ── Sign-up outline button ────────────────────────────────────
                OutlineActionButton(
                  text: 'Create an account',
                  icon: Icons.person_add_outlined,
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const SignupScreen()),
                  ),
                  height: 48,
                ),

                SizedBox(height: context.rs(24)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Ghost icon button ────────────────────────────────────────────────────────
class _GhostIconButton extends StatelessWidget {
  final IconData icon;
  final bool isDark;
  final VoidCallback onTap;

  const _GhostIconButton({
    required this.icon,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: context.rs(42),
        height: context.rs(42),
        decoration: BoxDecoration(
          color: isDark ? AppTheme.neutral800 : AppTheme.neutral100,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
          ),
        ),
        child: Icon(
          icon,
          size: 18,
          color: isDark ? Colors.white : AppTheme.notionBlack,
        ),
      ),
    );
  }
}
