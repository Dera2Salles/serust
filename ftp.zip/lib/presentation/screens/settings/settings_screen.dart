import 'package:arosaina/core/injection.dart';
import 'package:arosaina/engine/services/interfaces/i_auth_service.dart';
import 'package:arosaina/engine/services/interfaces/i_settings_service.dart';
import 'package:arosaina/presentation/bloc/settings/settings_cubit.dart';
import 'package:arosaina/presentation/common/responsive.dart';
import 'package:arosaina/presentation/screens/auth/login_screen.dart';
import 'package:arosaina/presentation/theme/app_theme.dart';
import 'package:arosaina/presentation/widgets/premium_components.dart';
import 'package:arosaina/presentation/widgets/server_config_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final user = sl<IAuthService>().getCurrentUser();
    final primary = isDark ? Colors.white : AppTheme.notionBlack;
    final bg = isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight;
    final cardBg = isDark ? AppTheme.notionSurface : Colors.white;
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Page header ───────────────────────────────────────────────────
            Padding(
              padding: EdgeInsets.fromLTRB(
                context.rs(20),
                context.rs(20),
                context.rs(20),
                0,
              ),
              child: Row(
                children: [
                  Text(
                    'Settings',
                    style: TextStyle(
                      fontSize: context.rf(22),
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5,
                      color: isDark ? Colors.white : AppTheme.neutral900,
                    ),
                  ),
                  const Spacer(),
                  // Shadcn Badge showing version
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: isDark ? AppTheme.neutral800 : AppTheme.neutral100,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: border),
                    ),
                    child: Text(
                      'v1.0.0',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.neutral500,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: ListView(
                padding: EdgeInsets.all(context.rs(20)),
                children: [
                  SizedBox(height: context.rs(8)),

                  // ── Profile card ────────────────────────────────────────────
                  if (user != null) ...[
                    Container(
                      padding: EdgeInsets.all(context.rs(16)),
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: border),
                      ),
                      child: Row(
                        children: [
                          // Avatar
                          Container(
                            width: context.rs(50),
                            height: context.rs(50),
                            decoration: BoxDecoration(
                              color: primary,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Center(
                              child: Text(
                                user.username[0].toUpperCase(),
                                style: TextStyle(
                                  color: isDark
                                      ? AppTheme.notionBlack
                                      : Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: context.rs(14)),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  user.username,
                                  style: TextStyle(
                                    color: isDark
                                        ? Colors.white
                                        : AppTheme.neutral900,
                                    fontSize: context.rf(15),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                SizedBox(height: context.rs(2)),
                                Text(
                                  user.email,
                                  style: TextStyle(
                                    color: AppTheme.neutral500,
                                    fontSize: context.rf(12),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Verified badge
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 7,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.green.withValues(alpha: 0.08),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: Colors.green.withValues(alpha: 0.2),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.check_circle_rounded,
                                  color: Colors.green,
                                  size: 11,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  'Active',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.green.shade600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: context.rs(24)),
                  ],

                  // ── Appearance ──────────────────────────────────────────────
                  _SectionLabel(label: 'APPEARANCE'),
                  SizedBox(height: context.rs(8)),
                  SoftCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.palette_outlined,
                              size: 15,
                              color: AppTheme.neutral500,
                            ),
                            SizedBox(width: context.rs(6)),
                            Text(
                              'Theme color',
                              style: TextStyle(
                                fontSize: context.rf(13),
                                fontWeight: FontWeight.w600,
                                color: isDark
                                    ? Colors.white
                                    : AppTheme.neutral900,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: context.rs(14)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: AppTheme.themeColors.map((color) {
                            final isSelected =
                                Theme.of(context).primaryColor == color;
                            return GestureDetector(
                              onTap: () => context
                                  .read<SettingsCubit>()
                                  .setThemeColor(color),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                width: context.rs(38),
                                height: context.rs(38),
                                decoration: BoxDecoration(
                                  color: color,
                                  borderRadius: BorderRadius.circular(10),
                                  border: isSelected
                                      ? Border.all(color: color, width: 2.5)
                                      : Border.all(color: border, width: 1),
                                ),
                                child: isSelected
                                    ? const Icon(
                                        Icons.check_rounded,
                                        color: Colors.white,
                                        size: 18,
                                      )
                                    : null,
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: context.rs(20)),

                  // ── Language ─────────────────────────────────────────────────
                  _SectionLabel(label: 'LANGUAGE'),
                  SizedBox(height: context.rs(8)),
                  SoftCard(
                    child: Row(
                      children: [
                        _LangButton(
                          label: 'English',
                          locale: const Locale('en'),
                        ),
                        SizedBox(width: context.rs(8)),
                        _LangButton(
                          label: 'Français',
                          locale: const Locale('fr'),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: context.rs(20)),

                  // ── Server ───────────────────────────────────────────────────
                  _SectionLabel(label: 'SERVER'),
                  SizedBox(height: context.rs(8)),
                  SoftCard(
                    child: Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: isDark
                                ? AppTheme.neutral800
                                : AppTheme.neutral100,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: border),
                          ),
                          child: Icon(
                            Icons.dns_rounded,
                            size: 16,
                            color: isDark ? Colors.white : AppTheme.notionBlack,
                          ),
                        ),
                        SizedBox(width: context.rs(12)),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Server URL',
                                style: TextStyle(
                                  fontSize: context.rf(13),
                                  fontWeight: FontWeight.w600,
                                  color: isDark
                                      ? Colors.white
                                      : AppTheme.neutral900,
                                ),
                              ),
                              SizedBox(height: context.rs(2)),
                              Text(
                                sl<ISettingsService>().apiBaseUrl,
                                style: TextStyle(
                                  fontSize: context.rf(11),
                                  color: AppTheme.neutral500,
                                  fontWeight: FontWeight.w400,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        // Shadcn ghost icon button for edit
                        GestureDetector(
                          onTap: () => ServerConfigDialog.show(context),
                          child: Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              color: isDark
                                  ? AppTheme.neutral800
                                  : AppTheme.neutral100,
                              borderRadius: BorderRadius.circular(9),
                              border: Border.all(color: border),
                            ),
                            child: Icon(
                              Icons.edit_outlined,
                              size: 15,
                              color: isDark
                                  ? Colors.white70
                                  : AppTheme.neutral600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: context.rs(20)),

                  // ── About ────────────────────────────────────────────────────
                  _SectionLabel(label: 'ABOUT'),
                  SizedBox(height: context.rs(8)),
                  SoftCard(
                    child: Column(
                      children: [
                        _InfoRow(label: 'Version', value: '1.0.0'),
                        _RowDivider(isDark: isDark),
                        _InfoRow(label: 'Encryption', value: 'AES-256-GCM'),
                        _RowDivider(isDark: isDark),
                        _InfoRow(label: 'Protocol', value: 'FTP / HTTP'),
                        _RowDivider(isDark: isDark),
                        _InfoRow(
                          label: 'Storage',
                          value: 'Local FTP',
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.folderYellowBg,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: const Text(
                              'Beta',
                              style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.folderYellow,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: context.rs(24)),

                  // ── Danger zone — shadcn DestructiveButton style ─────────────
                  if (user != null) ...[
                    Container(
                      decoration: BoxDecoration(
                        color: isDark ? AppTheme.notionSurface : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.red.withValues(alpha: 0.25),
                        ),
                      ),
                      padding: EdgeInsets.all(context.rs(16)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.warning_amber_rounded,
                                color: Colors.red,
                                size: 15,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'DANGER ZONE',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 1.2,
                                  color: Colors.red,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: context.rs(12)),
                          _DestructiveButton(
                            label: 'Sign out of AroSaina',
                            onTap: () async {
                              await sl<IAuthService>().logout();
                              if (context.mounted) {
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const LoginScreen(),
                                  ),
                                  (_) => false,
                                );
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                  ],

                  SizedBox(height: context.rs(32)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: TextStyle(
        fontSize: context.rf(10),
        fontWeight: FontWeight.w800,
        letterSpacing: 1.4,
        color: AppTheme.neutral400,
      ),
    );
  }
}

class _RowDivider extends StatelessWidget {
  final bool isDark;
  const _RowDivider({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Divider(
      height: context.rs(20),
      color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final Widget? trailing;
  const _InfoRow({required this.label, required this.value, this.trailing});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: context.rf(13),
            fontWeight: FontWeight.w500,
            color: AppTheme.neutral500,
          ),
        ),
        Row(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: context.rf(13),
                fontWeight: FontWeight.w700,
                color: isDark ? Colors.white : AppTheme.neutral900,
              ),
            ),
            if (trailing != null) ...[const SizedBox(width: 6), trailing!],
          ],
        ),
      ],
    );
  }
}

class _LangButton extends StatelessWidget {
  final String label;
  final Locale locale;
  const _LangButton({required this.label, required this.locale});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final primary = isDark ? Colors.white : AppTheme.notionBlack;
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;
    final currentLocale = Localizations.localeOf(context);
    final isActive = currentLocale.languageCode == locale.languageCode;

    return Expanded(
      child: GestureDetector(
        onTap: () => context.read<SettingsCubit>().setLocale(locale),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: EdgeInsets.symmetric(vertical: context.rs(10)),
          decoration: BoxDecoration(
            color: isActive ? primary : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isActive ? primary : border,
              width: isActive ? 1.5 : 1,
            ),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                fontSize: context.rf(13),
                fontWeight: FontWeight.w600,
                color: isActive
                    ? (isDark ? AppTheme.notionBlack : Colors.white)
                    : AppTheme.neutral500,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _DestructiveButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;

  const _DestructiveButton({required this.label, required this.onTap});

  @override
  State<_DestructiveButton> createState() => _DestructiveButtonState();
}

class _DestructiveButtonState extends State<_DestructiveButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      duration: const Duration(milliseconds: 80),
      vsync: this,
    );
    _scale = Tween<double>(
      begin: 1.0,
      end: 0.97,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: context.rs(13)),
          decoration: BoxDecoration(
            color: Colors.red.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.red.withValues(alpha: 0.25)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.logout_rounded, color: Colors.red, size: 16),
              SizedBox(width: context.rs(8)),
              Text(
                widget.label,
                style: TextStyle(
                  color: Colors.red,
                  fontSize: context.rf(14),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
