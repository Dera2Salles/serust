import 'package:arosaina/core/injection.dart';
import 'package:arosaina/engine/models/ai_message.dart';
import 'package:arosaina/presentation/bloc/ai_chat/ai_chat_bloc.dart';
import 'package:arosaina/presentation/common/responsive.dart';
import 'package:arosaina/presentation/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// ── Screen ───────────────────────────────────────────────────────────────────

class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key});

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final _ctrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  @override
  void dispose() {
    _ctrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight;
    final primary = Theme.of(context).primaryColor;
    final textPrimary = isDark ? Colors.white : AppTheme.notionBlack;
    final textSecondary = isDark
        ? AppTheme.notionTextSecondaryDark
        : AppTheme.notionTextSecondaryLight;
    final divider = isDark
        ? AppTheme.notionDividerDark
        : AppTheme.notionDividerLight;

    return BlocProvider(
      create: (context) => sl<AiChatBloc>()..add(AiChatStarted()),
      child: Scaffold(
        backgroundColor: bg,
        body: SafeArea(
          child: BlocConsumer<AiChatBloc, AiChatState>(
            listener: (context, state) {
              _scrollToBottom();
            },
            builder: (context, state) {
              final messages = state.messages;
              final isSending = state.status == AiChatStatus.loading;

              return Column(
                children: [
                  // ── Header ──────────────────────────────────────────────────
                  Container(
                    padding: EdgeInsets.fromLTRB(
                      context.rs(20),
                      context.rs(20),
                      context.rs(20),
                      context.rs(12),
                    ),
                    decoration: BoxDecoration(
                      color: bg,
                      border: Border(
                        bottom: BorderSide(color: divider, width: 1),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: primary,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.auto_awesome_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                        SizedBox(width: context.rs(12)),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Gemini Assistant',
                              style: TextStyle(
                                fontSize: context.rf(16),
                                fontWeight: FontWeight.w800,
                                color: textPrimary,
                                letterSpacing: -0.3,
                              ),
                            ),
                            Text(
                              'Manage files with Google Gemini',
                              style: TextStyle(
                                fontSize: context.rf(11),
                                color: textSecondary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        GestureDetector(
                          onTap: () {
                            context.read<AiChatBloc>().add(AiChatReset());
                          },
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: isDark
                                  ? AppTheme.notionSurface
                                  : AppTheme.neutral100,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.refresh_rounded,
                              size: 16,
                              color: textSecondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ── Messages ─────────────────────────────────────────────────
                  Expanded(
                    child: ListView.builder(
                      controller: _scrollCtrl,
                      padding: EdgeInsets.symmetric(
                        horizontal: context.rs(16),
                        vertical: context.rs(16),
                      ),
                      itemCount: messages.length,
                      itemBuilder: (_, i) => _MessageBubble(
                        message: messages[i],
                        isDark: isDark,
                        primary: primary,
                        textPrimary: textPrimary,
                        textSecondary: textSecondary,
                      ),
                    ),
                  ),

                  // ── Quick suggestions ─────────────────────────────────────────
                  if (messages.length <= 2)
                    _QuickSuggestions(
                      onTap: (text) {
                        _ctrl.text = text;
                        context.read<AiChatBloc>().add(AiChatMessageSent(text));
                        _ctrl.clear();
                      },
                      isDark: isDark,
                      primary: primary,
                      textSecondary: textSecondary,
                    ),

                  // ── Input bar ─────────────────────────────────────────────────
                  Container(
                    padding: EdgeInsets.fromLTRB(
                      context.rs(16),
                      context.rs(12),
                      context.rs(16),
                      context.rs(12),
                    ),
                    decoration: BoxDecoration(
                      color: bg,
                      border: Border(top: BorderSide(color: divider, width: 1)),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: isDark
                                  ? AppTheme.notionSurface
                                  : AppTheme.neutral100,
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: divider),
                            ),
                            child: TextField(
                              controller: _ctrl,
                              enabled: !isSending,
                              maxLines: null,
                              keyboardType: TextInputType.multiline,
                              textInputAction: TextInputAction.send,
                              onSubmitted: (val) {
                                if (val.trim().isNotEmpty) {
                                  context.read<AiChatBloc>().add(
                                    AiChatMessageSent(val),
                                  );
                                  _ctrl.clear();
                                }
                              },
                              style: TextStyle(
                                color: textPrimary,
                                fontSize: context.rf(14),
                              ),
                              decoration: InputDecoration(
                                hintText: 'Ask about your files...',
                                hintStyle: TextStyle(
                                  color: textSecondary,
                                  fontSize: context.rf(14),
                                ),
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: context.rs(16),
                                  vertical: context.rs(12),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: context.rs(10)),
                        GestureDetector(
                          onTap: isSending
                              ? null
                              : () {
                                  if (_ctrl.text.trim().isNotEmpty) {
                                    context.read<AiChatBloc>().add(
                                      AiChatMessageSent(_ctrl.text),
                                    );
                                    _ctrl.clear();
                                  }
                                },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 150),
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: isSending
                                  ? primary.withValues(alpha: 0.4)
                                  : primary,
                              shape: BoxShape.circle,
                            ),
                            child: isSending
                                ? const Padding(
                                    padding: EdgeInsets.all(12),
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Icon(
                                    Icons.arrow_upward_rounded,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

// ─── Message Bubble ───────────────────────────────────────────────────────────

class _MessageBubble extends StatelessWidget {
  final AiMessage message;
  final bool isDark;
  final Color primary;
  final Color textPrimary;
  final Color textSecondary;

  const _MessageBubble({
    required this.message,
    required this.isDark,
    required this.primary,
    required this.textPrimary,
    required this.textSecondary,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == AiRole.user;

    return Padding(
      padding: EdgeInsets.only(bottom: context.rs(12)),
      child: Row(
        mainAxisAlignment: isUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            Container(
              width: 28,
              height: 28,
              margin: const EdgeInsets.only(right: 8, bottom: 2),
              decoration: BoxDecoration(color: primary, shape: BoxShape.circle),
              child: const Icon(
                Icons.auto_awesome_rounded,
                color: Colors.white,
                size: 14,
              ),
            ),
          ],

          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isUser
                    ? primary
                    : (isDark ? AppTheme.notionSurface : AppTheme.neutral100),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isUser ? 18 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 18),
                ),
              ),
              child: message.isLoading
                  ? _LoadingFunMessage(color: textSecondary)
                  : Text(
                      message.text,
                      style: TextStyle(
                        color: isUser ? Colors.white : textPrimary,
                        fontSize: context.rf(14),
                        height: 1.4,
                      ),
                    ),
            ),
          ),

          if (isUser) const SizedBox(width: 36),
        ],
      ),
    );
  }
}

// ─── Typing Indicator ─────────────────────────────────────────────────────────

class _TypingIndicator extends StatefulWidget {
  final Color color;
  const _TypingIndicator({required this.color});

  @override
  State<_TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<_TypingIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, _) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final delay = i / 3;
            final phase = (_ctrl.value - delay).abs() % 1.0;
            final opacity = phase < 0.5 ? phase * 2 : (1 - phase) * 2;
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 2),
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                color: widget.color.withValues(alpha: 0.3 + opacity * 0.7),
                shape: BoxShape.circle,
              ),
            );
          }),
        );
      },
    );
  }
}

// ─── Loading Fun Message ──────────────────────────────────────────────────────

class _LoadingFunMessage extends StatefulWidget {
  final Color color;
  const _LoadingFunMessage({required this.color});

  @override
  State<_LoadingFunMessage> createState() => _LoadingFunMessageState();
}

class _LoadingFunMessageState extends State<_LoadingFunMessage> {
  late final Stream<int> _timer;

  final _messages = [
    "🌀 Gathering file metadata...",
    "📡 Pinging the FTP server...",
    "📂 Scanning folders for treasure...",
    "🧪 Analyzing your request...",
    "🧠 Consulting the Gemini oracle...",
    "🚀 Optimizing data packets...",
    "📜 Reading between the binary lines...",
    "🔗 Establishing a secure link...",
    "💾 Checking storage capacity...",
    "🧹 Tidying up the file system...",
    "⚡ Energizing the network...",
    "📟 Waiting for server handshake...",
    "🪐 Pinging a distant galaxy...",
    "🛠️ Polishing the mainframe...",
    "🚂 Chugging through the bits...",
  ];

  @override
  void initState() {
    super.initState();
    _timer = Stream.periodic(const Duration(seconds: 2), (i) => (i + 1) % _messages.length);
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<int>(
      stream: _timer,
      initialData: 0,
      builder: (context, snapshot) {
        final text = _messages[snapshot.data ?? 0];
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _TypingIndicator(color: widget.color),
            const SizedBox(width: 12),
            Text(
              text,
              style: TextStyle(
                color: widget.color,
                fontSize: context.rf(12),
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        );
      }
    );
  }
}

// ─── Quick Suggestions ────────────────────────────────────────────────────────

class _QuickSuggestions extends StatelessWidget {
  final void Function(String) onTap;
  final bool isDark;
  final Color primary;
  final Color textSecondary;

  const _QuickSuggestions({
    required this.onTap,
    required this.isDark,
    required this.primary,
    required this.textSecondary,
  });

  @override
  Widget build(BuildContext context) {
    final suggestions = [
      'What files do I have?',
      'How much storage am I using?',
      'Find all my images',
      'Organize my files by type',
    ];

    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: context.rs(16)),
        itemCount: suggestions.length,
        separatorBuilder: (_, _) => const SizedBox(width: 8),
        itemBuilder: (_, i) => GestureDetector(
          onTap: () => onTap(suggestions[i]),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: primary.withValues(alpha: 0.2)),
            ),
            child: Text(
              suggestions[i],
              style: TextStyle(
                fontSize: context.rf(12),
                color: primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
