import 'package:arosaina/core/injection.dart';
import 'package:arosaina/engine/connection/i_ftp_datasource.dart';
import 'package:arosaina/engine/models/ftp_entry.dart';
import 'package:arosaina/engine/services/interfaces/i_auth_service.dart';
import 'package:arosaina/presentation/common/responsive.dart';
import 'package:arosaina/presentation/screens/ai/ai_chat_screen.dart';
import 'package:arosaina/presentation/screens/explorer/explorer_screen.dart';
import 'package:arosaina/presentation/screens/settings/settings_screen.dart';
import 'package:arosaina/presentation/theme/app_theme.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    _HomeTab(),
    ExplorerScreen(),
    AiChatScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: _ShadcnNavBar(
        isDark: isDark,
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
      ),
    );
  }
}

// ── Shadcn-style Bottom Navigation ────────────────────────────────────────────

class _ShadcnNavBar extends StatelessWidget {
  final bool isDark;
  final int currentIndex;
  final void Function(int) onTap;

  const _ShadcnNavBar({
    required this.isDark,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final bg = isDark ? AppTheme.notionSurface : Colors.white;
    final border = isDark
        ? AppTheme.notionDividerDark
        : AppTheme.notionDividerLight;

    return Container(
      decoration: BoxDecoration(
        color: bg,
        border: Border(top: BorderSide(color: border, width: 1)),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _NavItem(
                icon: Icons.home_rounded,
                label: 'Home',
                index: 0,
                current: currentIndex,
                isDark: isDark,
                onTap: onTap,
              ),
              _NavItem(
                icon: Icons.folder_rounded,
                label: 'Files',
                index: 1,
                current: currentIndex,
                isDark: isDark,
                onTap: onTap,
              ),
              _NavItem(
                icon: Icons.auto_awesome_rounded,
                label: 'AI',
                index: 2,
                current: currentIndex,
                isDark: isDark,
                onTap: onTap,
              ),
              _NavItem(
                icon: Icons.settings_rounded,
                label: 'Settings',
                index: 3,
                current: currentIndex,
                isDark: isDark,
                onTap: onTap,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final int index;
  final int current;
  final bool isDark;
  final void Function(int) onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.index,
    required this.current,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = index == current;
    final primary = isDark ? Colors.white : AppTheme.notionBlack;
    // Folder icon (index 1) gets yellow when active
    final Color iconColor;
    if (active) {
      iconColor = index == 1 ? AppTheme.folderYellow : primary;
    } else {
      iconColor = AppTheme.neutral400;
    }

    return GestureDetector(
      onTap: () => onTap(index),
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
              decoration: BoxDecoration(
                color: active
                    ? (index == 1
                          ? AppTheme.folderYellowBg
                          : (isDark ? Colors.white12 : AppTheme.neutral100))
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(22),
              ),
              child: Icon(icon, color: iconColor, size: 22),
            ),
            const SizedBox(height: 2),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 200),
              style: TextStyle(
                fontSize: 10,
                fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                color: active ? iconColor : AppTheme.neutral400,
                letterSpacing: 0.2,
              ),
              child: Text(label),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Home Tab ─────────────────────────────────────────────────────────────────

class _HomeTab extends StatefulWidget {
  const _HomeTab();

  @override
  State<_HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<_HomeTab> {
  _StorageInfo? _storageInfo;
  bool _loadingStorage = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadStorageInfo();
  }

  Future<void> _loadStorageInfo() async {
    setState(() {
      _loadingStorage = true;
      _error = null;
    });
    try {
      final datasource = sl<IFtpDataSource>();
      await datasource.connect();
      final entries = await _listAllRecursive(datasource, '/');
      final totalBytes = entries.fold<int>(0, (s, e) => s + e.size);
      final fileCount = entries.where((e) => !e.isDirectory).length;
      final folderCount = entries.where((e) => e.isDirectory).length;
      if (mounted) {
        setState(() {
          _storageInfo = _StorageInfo(
            totalBytes: totalBytes,
            fileCount: fileCount,
            folderCount: folderCount,
          );
          _loadingStorage = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loadingStorage = false;
          _error = e.toString();
        });
      }
    }
  }

  Future<List<FtpEntry>> _listAllRecursive(
    IFtpDataSource ds,
    String path,
  ) async {
    try {
      await ds.changeDir(path);
      final entries = await ds.listDirectory();
      final result = <FtpEntry>[];
      for (final e in entries) {
        result.add(e);
        if (e.isDirectory) {
          final sub = path == '/' ? '/${e.name}' : '$path/${e.name}';
          result.addAll(await _listAllRecursive(ds, sub));
          await ds.changeDir(path);
        }
      }
      return result;
    } catch (_) {
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final user = sl<IAuthService>().getCurrentUser();
    final firstName = user?.username.split(' ').first ?? 'User';
    final primary = isDark ? Colors.white : AppTheme.notionBlack;

    return Scaffold(
      backgroundColor: isDark
          ? AppTheme.backgroundDark
          : AppTheme.backgroundLight,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Bar ──────────────────────────────────────────────────────
            Padding(
              padding: EdgeInsets.fromLTRB(
                context.rs(20),
                context.rs(20),
                context.rs(20),
                0,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Hello, $firstName 👋',
                          style: TextStyle(
                            fontSize: context.rf(22),
                            fontWeight: FontWeight.w800,
                            color: isDark ? Colors.white : AppTheme.neutral900,
                            letterSpacing: -0.5,
                          ),
                        ),
                        Text(
                          'Your personal FTP storage',
                          style: TextStyle(
                            fontSize: context.rf(13),
                            color: AppTheme.neutral500,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Avatar — shadcn-style with thick border
                  Container(
                    width: context.rs(44),
                    height: context.rs(44),
                    decoration: BoxDecoration(
                      color: primary,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isDark
                            ? AppTheme.neutral700
                            : AppTheme.neutral200,
                        width: 1.5,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        firstName[0].toUpperCase(),
                        style: TextStyle(
                          color: isDark ? AppTheme.notionBlack : Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: RefreshIndicator(
                onRefresh: _loadStorageInfo,
                color: primary,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.all(context.rs(20)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: context.rs(24)),

                      // ── Storage Card ──────────────────────────────────────
                      _StorageCard(
                        info: _storageInfo,
                        loading: _loadingStorage,
                        error: _error,
                        isDark: isDark,
                      ),

                      SizedBox(height: context.rs(20)),

                      // ── Quick Stats Section ───────────────────────────────
                      Row(
                        children: [
                          Text(
                            'BREAKDOWN',
                            style: TextStyle(
                              fontSize: context.rf(10),
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1.5,
                              color: AppTheme.neutral400,
                            ),
                          ),
                          const Spacer(),
                          // shadcn Badge-style chip
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: isDark
                                  ? AppTheme.neutral800
                                  : AppTheme.neutral100,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: isDark
                                    ? AppTheme.neutral700
                                    : AppTheme.neutral200,
                              ),
                            ),
                            child: Text(
                              'Live',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.neutral500,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: context.rs(12)),

                      Row(
                        children: [
                          Expanded(
                            child: _InfoCard(
                              icon: Icons.insert_drive_file_rounded,
                              value: _loadingStorage
                                  ? '—'
                                  : '${_storageInfo?.fileCount ?? 0}',
                              label: 'Files',
                              iconColor: isDark
                                  ? Colors.white70
                                  : AppTheme.neutral600,
                              isDark: isDark,
                            ),
                          ),
                          SizedBox(width: context.rs(10)),
                          // Folder card always gets yellow icon
                          Expanded(
                            child: _InfoCard(
                              icon: Icons.folder_rounded,
                              value: _loadingStorage
                                  ? '—'
                                  : '${_storageInfo?.folderCount ?? 0}',
                              label: 'Folders',
                              iconColor: AppTheme.folderYellow,
                              isDark: isDark,
                              iconBg: AppTheme.folderYellowBg,
                            ),
                          ),
                          SizedBox(width: context.rs(10)),
                          Expanded(
                            child: _InfoCard(
                              icon: Icons.storage_rounded,
                              value: _loadingStorage
                                  ? '—'
                                  : _formatBytes(_storageInfo?.totalBytes ?? 0),
                              label: 'Used',
                              iconColor: isDark
                                  ? Colors.white54
                                  : AppTheme.neutral500,
                              isDark: isDark,
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: context.rs(24)),

                      // ── Security Banner — shadcn outline card style ────────
                      _SecurityBanner(isDark: isDark),

                      SizedBox(height: context.rs(16)),

                      // ── Quick Actions ─────────────────────────────────────
                      Text(
                        'QUICK ACTIONS',
                        style: TextStyle(
                          fontSize: context.rf(10),
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                          color: AppTheme.neutral400,
                        ),
                      ),
                      SizedBox(height: context.rs(10)),
                      _QuickActions(isDark: isDark),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}

// ─── Storage Info Model ───────────────────────────────────────────────────────

class _StorageInfo {
  final int totalBytes;
  final int fileCount;
  final int folderCount;

  const _StorageInfo({
    required this.totalBytes,
    required this.fileCount,
    required this.folderCount,
  });
}

// ─── Storage Card ─────────────────────────────────────────────────────────────

class _StorageCard extends StatelessWidget {
  final _StorageInfo? info;
  final bool loading;
  final String? error;
  final bool isDark;

  const _StorageCard({
    required this.info,
    required this.loading,
    required this.isDark,
    this.error,
  });

  @override
  Widget build(BuildContext context) {
    final primary = isDark ? Colors.white : AppTheme.notionBlack;
    final bg = isDark ? AppTheme.notionSurface : Colors.white;
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;

    const int softMax = 10 * 1024 * 1024 * 1024;
    final used = info?.totalBytes ?? 0;
    final fraction = (used / softMax).clamp(0.0, 1.0);

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(context.rs(22)),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: isDark ? AppTheme.neutral800 : AppTheme.neutral100,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
                  ),
                ),
                child: Icon(
                  Icons.dns_rounded,
                  color: isDark ? Colors.white : AppTheme.notionBlack,
                  size: 16,
                ),
              ),
              SizedBox(width: context.rs(10)),
              Text(
                'Server Storage',
                style: TextStyle(
                  fontSize: context.rf(14),
                  fontWeight: FontWeight.w700,
                  color: isDark ? Colors.white : AppTheme.neutral900,
                ),
              ),
              const Spacer(),
              if (loading)
                SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: primary,
                  ),
                ),
            ],
          ),

          SizedBox(height: context.rs(20)),

          if (error != null && !loading)
            Text(
              'Could not load storage info',
              style: TextStyle(
                fontSize: context.rf(13),
                color: AppTheme.neutral500,
              ),
            )
          else if (loading)
            Container(
              height: 60,
              decoration: BoxDecoration(
                color: isDark ? AppTheme.neutral800 : AppTheme.neutral100,
                borderRadius: BorderRadius.circular(10),
              ),
            )
          else ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  _formatBytes(used),
                  style: TextStyle(
                    fontSize: context.rf(34),
                    fontWeight: FontWeight.w900,
                    color: isDark ? Colors.white : AppTheme.neutral900,
                    letterSpacing: -1,
                    height: 1,
                  ),
                ),
                SizedBox(width: context.rs(6)),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    'used',
                    style: TextStyle(
                      fontSize: context.rf(13),
                      color: AppTheme.neutral500,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: context.rs(16)),

            // Progress bar — shadcn-style (thin, sharp)
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: fraction,
                minHeight: 4,
                backgroundColor: isDark
                    ? AppTheme.neutral700
                    : AppTheme.neutral200,
                valueColor: AlwaysStoppedAnimation<Color>(primary),
              ),
            ),

            SizedBox(height: context.rs(8)),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${(fraction * 100).toStringAsFixed(1)}% of 10 GB',
                  style: TextStyle(
                    fontSize: context.rf(11),
                    color: AppTheme.neutral500,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  '${_formatBytes((softMax - used).clamp(0, softMax))} free',
                  style: TextStyle(
                    fontSize: context.rf(11),
                    color: AppTheme.neutral500,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 0) bytes = 0;
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}

// ─── Info Card ────────────────────────────────────────────────────────────────

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color iconColor;
  final Color? iconBg;
  final bool isDark;

  const _InfoCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.iconColor,
    required this.isDark,
    this.iconBg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        vertical: context.rs(14),
        horizontal: context.rs(12),
      ),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.neutral800 : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: iconBg ?? iconColor.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: iconColor, size: 16),
          ),
          SizedBox(height: context.rs(10)),
          Text(
            value,
            style: TextStyle(
              fontSize: context.rf(18),
              fontWeight: FontWeight.w800,
              color: isDark ? Colors.white : AppTheme.neutral900,
              letterSpacing: -0.5,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: context.rf(10),
              color: AppTheme.neutral500,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Security Banner ──────────────────────────────────────────────────────────

class _SecurityBanner extends StatelessWidget {
  final bool isDark;
  const _SecurityBanner({required this.isDark});

  @override
  Widget build(BuildContext context) {
    final primary = isDark ? Colors.white : AppTheme.notionBlack;
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(context.rs(18)),
      decoration: BoxDecoration(
        color: primary,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'AES-256 Encrypted',
                  style: TextStyle(
                    fontSize: context.rf(15),
                    fontWeight: FontWeight.w800,
                    color: isDark ? AppTheme.notionBlack : Colors.white,
                    letterSpacing: -0.3,
                  ),
                ),
                SizedBox(height: context.rs(4)),
                Text(
                  'End-to-end secure transfer',
                  style: TextStyle(
                    fontSize: context.rf(12),
                    color: isDark
                        ? AppTheme.notionBlack.withValues(alpha: 0.55)
                        : Colors.white.withValues(alpha: 0.7),
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.shield_rounded,
            size: context.rs(44),
            color: isDark
                ? AppTheme.notionBlack.withValues(alpha: 0.15)
                : Colors.white.withValues(alpha: 0.2),
          ),
        ],
      ),
    );
  }
}

// ─── Quick Actions ─────────────────────────────────────────────────────────────

class _QuickActions extends StatelessWidget {
  final bool isDark;
  const _QuickActions({required this.isDark});

  @override
  Widget build(BuildContext context) {
    final items = [
      (
        Icons.folder_rounded,
        'Browse Files',
        AppTheme.folderYellow,
        AppTheme.folderYellowBg,
      ),
      (
        Icons.upload_rounded,
        'Upload',
        isDark ? Colors.white70 : AppTheme.neutral600,
        isDark ? Colors.white12 : AppTheme.neutral100,
      ),
      (
        Icons.download_rounded,
        'Download',
        isDark ? Colors.white70 : AppTheme.neutral600,
        isDark ? Colors.white12 : AppTheme.neutral100,
      ),
    ];

    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;
    final cardBg = isDark ? AppTheme.notionSurface : Colors.white;

    return Row(
      children: items.map((item) {
        final (icon, label, color, bgColor) = item;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(
              right: item == items.last ? 0 : context.rs(10),
            ),
            child: Container(
              padding: EdgeInsets.symmetric(
                vertical: context.rs(14),
                horizontal: context.rs(10),
              ),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: bgColor,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Icon(icon, color: color, size: 17),
                  ),
                  SizedBox(height: context.rs(10)),
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: context.rf(11),
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white : AppTheme.notionBlack,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}
