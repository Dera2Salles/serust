import 'package:flutter/material.dart';
import 'package:arosaina/engine/transfert/i.transfer.repository.dart';
import 'package:arosaina/core/injection.dart';
import 'package:arosaina/presentation/widgets/premium_components.dart';

class ShareDialog extends StatefulWidget {
  final String path;

  const ShareDialog({super.key, required this.path});

  static Future<void> show(BuildContext context, String path) {
    return showDialog(context: context, builder: (_) => ShareDialog(path: path));
  }

  @override
  State<ShareDialog> createState() => _ShareDialogState();
}

class _ShareDialogState extends State<ShareDialog> {
  final _userController = TextEditingController();
  bool _read = true;
  bool _write = false;
  bool _download = true;
  int? _reads;
  int? _downloads;
  int? _writes;
  final bool _reshare = false;

  Future<void> _share() async {
    final perm = StringBuffer();
    if (_read) perm.write('R');
    if (_write) perm.write('W');
    if (_download) perm.write('D');
    
    await sl<ITransferRepository>().shareFile(
      widget.path,
      _userController.text.trim(),
      perm.toString(),
      reads: _reads,
      downloads: _downloads,
      writes: _writes,
      reshare: _reshare,
    );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Share File'),
      content: SingleChildScrollView(
        child: Column(
          children: [
            ModernTextField(label: 'Recipient', hintText: 'Username', controller: _userController),
            SwitchListTile(title: const Text('Read'), value: _read, onChanged: (v) => setState(() => _read = v)),
            SwitchListTile(title: const Text('Write'), value: _write, onChanged: (v) => setState(() => _write = v)),
            SwitchListTile(title: const Text('Download'), value: _download, onChanged: (v) => setState(() => _download = v)),
            // ... Add numeric inputs for limits if needed ...
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        GradientButton(text: 'Share', onPressed: _share),
      ],
    );
  }
}
