import 'package:arosaina/presentation/common/responsive.dart';
import 'package:arosaina/presentation/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:shadcn_flutter/shadcn_flutter.dart' as shadcn;

// ─── AroSaina Design System — Shadcn Edition ─────────────────────────────────
// Black-and-white, minimal, flat. Yellow folder icons are the only color splash.

// ── Primary Action Button ─────────────────────────────────────────────────────

/// Full-width primary button using shadcn's Button primitive.
/// Solid fill, sharp corners, micro-scale animation on tap.
class GradientButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final LinearGradient? gradient; // kept for API compat — not used
  final bool isLoading;
  final IconData? icon;
  final double? width;
  final double height;
  final Color? color;

  const GradientButton({
    super.key,
    required this.text,
    this.onPressed,
    this.gradient,
    this.isLoading = false,
    this.icon,
    this.width,
    this.height = 54,
    this.color,
  });

  @override
  State<GradientButton> createState() => _GradientButtonState();
}

class _GradientButtonState extends State<GradientButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      duration: const Duration(milliseconds: 80),
      vsync: this,
    );
    _scale = Tween<double>(
      begin: 1.0,
      end: 0.96,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = widget.color ?? (isDark ? Colors.white : AppTheme.notionBlack);
    final fg = isDark ? AppTheme.notionBlack : Colors.white;

    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onPressed?.call();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          width: widget.width ?? double.infinity,
          height: context.rs(widget.height),
          decoration: BoxDecoration(
            color: widget.onPressed == null ? bg.withValues(alpha: 0.4) : bg,
            borderRadius: BorderRadius.circular(context.rs(12)),
          ),
          child: Center(
            child: widget.isLoading
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: fg,
                      strokeWidth: 2.0,
                    ),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (widget.icon != null) ...[
                        Icon(widget.icon, color: fg, size: context.rs(17)),
                        SizedBox(width: context.rs(8)),
                      ],
                      Text(
                        widget.text,
                        style: TextStyle(
                          color: fg,
                          fontSize: context.rf(15),
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.1,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

// ── Outline Button (secondary action) ────────────────────────────────────────

/// Shadcn-style outline button — transparent fill, visible border.
class OutlineActionButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final IconData? icon;
  final double height;

  const OutlineActionButton({
    super.key,
    required this.text,
    this.onPressed,
    this.icon,
    this.height = 48,
  });

  @override
  State<OutlineActionButton> createState() => _OutlineActionButtonState();
}

class _OutlineActionButtonState extends State<OutlineActionButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      duration: const Duration(milliseconds: 80),
      vsync: this,
    );
    _scale = Tween<double>(
      begin: 1.0,
      end: 0.97,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fg = isDark ? Colors.white : AppTheme.notionBlack;
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral300;

    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onPressed?.call();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          width: double.infinity,
          height: context.rs(widget.height),
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(context.rs(12)),
            border: Border.all(color: border, width: 1.5),
          ),
          child: Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (widget.icon != null) ...[
                  Icon(widget.icon, color: fg, size: context.rs(16)),
                  SizedBox(width: context.rs(8)),
                ],
                Text(
                  widget.text,
                  style: TextStyle(
                    color: fg,
                    fontSize: context.rf(14),
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.1,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── SoftCard ──────────────────────────────────────────────────────────────────

/// Shadcn-style card — sharp radius, 1 px border, zero elevation, zero shadow.
class SoftCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;
  final Color? backgroundColor;
  final double? borderRadius;

  const SoftCard({
    super.key,
    required this.child,
    this.padding,
    this.onTap,
    this.backgroundColor,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg =
        backgroundColor ?? (isDark ? AppTheme.notionSurface : Colors.white);
    final border = isDark ? AppTheme.neutral700 : AppTheme.neutral200;
    final radius = borderRadius ?? 14.0;

    Widget card = Container(
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: border, width: 1.0),
      ),
      padding: padding ?? const EdgeInsets.all(16),
      child: child,
    );

    if (onTap != null) {
      return GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: card,
      );
    }
    return card;
  }
}

// ── IllustrationCard ──────────────────────────────────────────────────────────

/// Top-strip card variant — monochrome fill.
class IllustrationCard extends StatelessWidget {
  final Widget child;
  final double aspectRatio;
  final LinearGradient? gradient; // kept for API compat
  final Color? solidColor;

  const IllustrationCard({
    super.key,
    required this.child,
    this.aspectRatio = 16 / 9,
    this.gradient,
    this.solidColor,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fill =
        solidColor ??
        (isDark ? AppTheme.notionSurface : AppTheme.notionLightSurface);
    return AspectRatio(
      aspectRatio: aspectRatio,
      child: Container(
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      ),
    );
  }
}

// ── ModernTextField ────────────────────────────────────────────────────────────

/// Shadcn-inspired text field — no floating label, crisp border on focus.
class ModernTextField extends StatelessWidget {
  final String label;
  final String hintText;
  final bool obscureText;
  final TextEditingController? controller;
  final TextInputType keyboardType;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final IconData? prefixIcon;
  final Widget? suffix;

  const ModernTextField({
    super.key,
    required this.label,
    required this.hintText,
    this.obscureText = false,
    this.controller,
    this.keyboardType = TextInputType.text,
    this.validator,
    this.onChanged,
    this.prefixIcon,
    this.suffix,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: context.rf(12),
            fontWeight: FontWeight.w600,
            letterSpacing: 0.4,
            color: isDark ? AppTheme.neutral400 : AppTheme.neutral600,
          ),
        ),
        SizedBox(height: context.rs(6)),
        TextFormField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          onChanged: onChanged,
          validator: validator,
          style: TextStyle(
            fontSize: context.rf(15),
            fontWeight: FontWeight.w500,
            color: isDark ? Colors.white : AppTheme.neutral900,
          ),
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(
              color: isDark ? AppTheme.neutral600 : AppTheme.neutral400,
              fontSize: context.rf(15),
              fontWeight: FontWeight.w400,
            ),
            prefixIcon: prefixIcon != null
                ? Icon(
                    prefixIcon,
                    color: isDark ? AppTheme.neutral500 : AppTheme.neutral400,
                    size: 18,
                  )
                : null,
            suffix: suffix,
            filled: true,
            fillColor: isDark ? AppTheme.neutral800 : AppTheme.neutral100,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                color: isDark ? Colors.white : AppTheme.notionBlack,
                width: 1.5,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Colors.red, width: 1.5),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Colors.red, width: 1.5),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: context.rs(14),
              vertical: context.rs(13),
            ),
          ),
        ),
      ],
    );
  }
}

// ── AroChip ───────────────────────────────────────────────────────────────────

/// Shadcn-style badge / pill chip.
class AroChip extends StatelessWidget {
  final String label;
  final Color color;
  final bool small;

  const AroChip({
    super.key,
    required this.label,
    required this.color,
    this.small = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: context.rs(small ? 7 : 10),
        vertical: context.rs(small ? 2 : 4),
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(100),
        border: Border.all(color: color.withValues(alpha: 0.25), width: 1),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: context.rf(small ? 10 : 12),
          fontWeight: FontWeight.w600,
          color: color,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}

// ── AroIconButton ─────────────────────────────────────────────────────────────

/// Shadcn ghost-style square icon button with optional active state.
class AroIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color? bgColor;
  final Color? iconColor;
  final double size;

  const AroIconButton({
    super.key,
    required this.icon,
    required this.onTap,
    this.bgColor,
    this.iconColor,
    this.size = 40,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: context.rs(size),
        height: context.rs(size),
        decoration: BoxDecoration(
          color:
              bgColor ?? (isDark ? AppTheme.neutral800 : AppTheme.neutral100),
          borderRadius: BorderRadius.circular(context.rs(size * 0.28)),
          border: Border.all(
            color: isDark ? AppTheme.neutral700 : AppTheme.neutral200,
          ),
        ),
        child: Icon(
          icon,
          size: context.rs(size * 0.43),
          color: iconColor ?? (isDark ? Colors.white : AppTheme.neutral700),
        ),
      ),
    );
  }
}

// ── ShadcnBadge ───────────────────────────────────────────────────────────────

/// Thin label badge — uses shadcn_flutter PrimaryBadge under the hood.
class ShadcnBadge extends StatelessWidget {
  final String label;

  const ShadcnBadge({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return shadcn.PrimaryBadge(
      child: Text(
        label,
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
      ),
    );
  }
}
