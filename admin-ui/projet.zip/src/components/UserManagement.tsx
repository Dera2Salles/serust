import React, { useState, useEffect } from 'react';
import { Header, SoftCard, AroChip, cn, ModernTextField } from './OneUI';
import { Users, UserPlus, Search, Edit3, Trash2, Shield, HardDrive, Mail, Key, X, Check } from 'lucide-react';
import { invoke } from '@tauri-apps/api/core';

interface User {
  username: string;
  email: string;
  quota_gb: number;
  is_admin: boolean;
  created_at: string;
}

export const UserManagement = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  
  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    quota_gb: 10,
    is_admin: false
  });

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const data = await invoke<User[]>('get_users_from_db');
      setUsers(data || []);
    } catch (err) {
      console.error("Fetch users failed:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await invoke('create_user_direct', { 
        username: formData.username,
        email: formData.email,
        password: formData.password,
        quotaGb: Number(formData.quota_gb),
        isAdmin: formData.is_admin
      });
      setIsCreateOpen(false);
      fetchUsers();
    } catch (e) {
      alert(e);
    }
  };

  const filteredUsers = users.filter(u => 
    u.username.toLowerCase().includes(query.toLowerCase()) || 
    u.email.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="flex flex-col w-full min-h-full bg-transparent pb-20">
      <Header 
        title="Utilisateurs" 
        subtitle="Gérer les comptes et quotas de stockage" 
      />

      <div className="px-10 flex flex-col md:flex-row gap-6 mb-10 items-center justify-between">
        <div className="relative w-full md:w-96 group">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-overlay1 group-focus-within:text-blue transition-colors" size={20} />
          <input 
            type="text" 
            placeholder="Rechercher un membre..."
            className="w-full pl-14 pr-6 py-4 bg-base rounded-[24px] border border-surface0/50 focus:border-blue outline-none transition-all font-bold text-text shadow-sm"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        
        <button 
          onClick={() => setIsCreateOpen(true)}
          className="oneui-button-primary w-full md:w-auto px-8 py-4"
        >
          <UserPlus size={20} />
          Ajouter Kajy
        </button>
      </div>

      <div className="px-10 space-y-4">
        {loading && users.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 opacity-30">
             <div className="w-10 h-10 border-4 border-blue/20 border-t-blue rounded-full animate-spin mb-6" />
             <p className="text-text font-black uppercase text-[10px] tracking-widest">Synchronisation SQL...</p>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="text-center py-32 opacity-20 border-2 border-dashed border-surface0 rounded-[40px]">
            <Users size={64} className="mx-auto mb-4" />
            <p className="text-2xl font-black tracking-tighter">Aucun utilisateur trouvé</p>
          </div>
        ) : (
          filteredUsers.map((user, i) => (
            <SoftCard key={i} className="flex flex-col md:flex-row md:items-center justify-between gap-6 group transition-all py-8 bg-base shadow-md hover:shadow-xl">
              <div className="flex items-center gap-7">
                <div className="w-16 h-16 rounded-[24px] bg-crust flex items-center justify-center text-blue shadow-inner relative">
                  <Users size={28} />
                  {user.is_admin && (
                    <div className="absolute -top-2 -right-2 w-7 h-7 bg-blue text-white rounded-lg flex items-center justify-center shadow-lg border-2 border-base">
                      <Shield size={14} fill="currentColor" />
                    </div>
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h4 className="font-black text-2xl tracking-tighter text-text">{user.username}</h4>
                    {user.is_admin && <AroChip label="Admin" color="blue" />}
                  </div>
                  <div className="flex flex-wrap items-center gap-5 text-sm font-bold text-overlay1">
                    <span className="flex items-center gap-2"><Mail size={14} /> {user.email}</span>
                    <span className="flex items-center gap-2 text-text opacity-60"><HardDrive size={14} /> {user.quota_gb} GB</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => { setEditingUser(user); setIsEditOpen(true); }}
                  className="p-4 bg-crust text-overlay1 rounded-2xl hover:bg-blue/5 hover:text-blue transition-all active:scale-90 border border-surface0"
                >
                  <Edit3 size={20} />
                </button>
                <button className="p-4 bg-crust text-overlay1 rounded-2xl hover:bg-red/5 hover:text-red transition-all active:scale-90 border border-surface0">
                  <Trash2 size={20} />
                </button>
              </div>
            </SoftCard>
          ))
        )}
      </div>

      {/* Modals with enhanced contrast */}
      {isCreateOpen && (
        <div className="fixed inset-0 bg-text/50 backdrop-blur-xl flex items-center justify-center z-[100] p-6 animate-in fade-in zoom-in duration-300">
          <SoftCard className="w-full max-w-lg p-10 border border-surface0 shadow-2xl relative bg-base">
            <button onClick={() => setIsCreateOpen(false)} className="absolute top-8 right-8 text-overlay1 hover:text-red transition-colors"><X size={24} /></button>
            <h3 className="text-3xl font-black text-text mb-2 tracking-tight">Nouveau Membre</h3>
            <p className="text-overlay1 font-bold text-xs uppercase tracking-widest opacity-60 mb-8">Création directe en base de données</p>
            
            <form onSubmit={handleCreateUser} className="space-y-5">
              <ModernTextField label="Nom d'utilisateur" icon={<Users size={18}/>} value={formData.username} onChange={v => setFormData({...formData, username: v})} placeholder="ex: alice_kajy" />
              <ModernTextField label="Adresse Email" icon={<Mail size={18}/>} value={formData.email} onChange={v => setFormData({...formData, email: v})} placeholder="alice@kajy.mg" />
              <ModernTextField label="Mot de passe" icon={<Key size={18}/>} type="password" value={formData.password} onChange={v => setFormData({...formData, password: v})} placeholder="********" />
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-overlay1 uppercase tracking-widest px-1">Quota (GB)</label>
                  <div className="relative">
                    <HardDrive className="absolute left-5 top-1/2 -translate-y-1/2 text-overlay1" size={16} />
                    <input type="number" className="w-full pl-12 pr-4 py-3 bg-crust rounded-2xl border border-surface0 focus:border-blue outline-none transition-all font-bold" value={formData.quota_gb} onChange={e => setFormData({...formData, quota_gb: Number(e.target.value)})} />
                  </div>
                </div>
                <div className="flex flex-col justify-end">
                  <button type="button" onClick={() => setFormData({...formData, is_admin: !formData.is_admin})} className={cn("flex items-center justify-center gap-3 px-6 py-3.5 rounded-2xl font-black text-xs transition-all border shadow-sm", formData.is_admin ? "bg-blue text-white border-blue shadow-blue/20" : "bg-crust text-subtext0 border-surface0")}>
                    <Shield size={16} /> Admin ?
                  </button>
                </div>
              </div>

              <button type="submit" className="oneui-button-primary w-full py-5 text-base mt-4 shadow-blue/30">
                <Check size={20} strokeWidth={3} />
                Confirmer l'inscription
              </button>
            </form>
          </SoftCard>
        </div>
      )}
    </div>
  );
};
