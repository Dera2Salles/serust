import { useState, useEffect } from 'react';
import { Header, SoftCard, AroChip, cn } from './OneUI';
import { Share2, Link as LinkIcon, User, Trash2, Calendar, RefreshCw, FileText, ExternalLink, ShieldCheck } from 'lucide-react';
import { invoke } from '@tauri-apps/api/core';

interface Share {
  id: string;
  type: 'direct' | 'link';
  owner: string;
  grantee: string;
  filename: string;
  path: string;
  token?: string;
  label?: string | null;
  can_read: boolean;
  can_write: boolean;
  expires_at: string | null;
  is_active?: boolean;
}

export const ShareManagement = () => {
  const [shares, setShares] = useState<Share[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchShares = async () => {
    setLoading(true);
    try {
      const data = await invoke<Share[]>('get_all_shares_db');
      setShares(data || []);
    } catch (err) {
      console.error("Failed to fetch shares:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleRevoke = async (share: Share) => {
    if (!confirm(`Voulez-vous vraiment révoquer définitivement le partage de "${share.filename}" ?`)) return;
    try {
      if (share.type === 'direct') {
        await invoke('revoke_share_grant_db', { id: share.id });
      } else {
        await invoke('revoke_share_link_db', { id: share.id });
      }
      fetchShares();
    } catch (err) {
      alert("Erreur lors de la révocation : " + err);
    }
  };

  useEffect(() => {
    fetchShares();
  }, []);

  return (
    <div className="flex flex-col w-full min-h-full bg-transparent pb-20">
      <Header 
        title="Partages" 
        subtitle="Surveillance de tous les accès et liens publics générés" 
      />

      <div className="px-10 mb-8 flex justify-end">
        <button 
          onClick={fetchShares}
          className="flex items-center gap-2 px-6 py-3.5 bg-white hover:bg-surface0 text-text border border-surface0 font-black rounded-[20px] transition-all active:scale-95 shadow-sm"
        >
          <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
          Actualiser
        </button>
      </div>

      <div className="px-10 space-y-5">
        {loading && shares.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 opacity-40">
             <div className="w-10 h-10 border-4 border-blue/20 border-t-blue rounded-full animate-spin mb-4" />
             <p className="text-overlay1 font-black uppercase text-[10px] tracking-widest">Scan des partages...</p>
          </div>
        ) : shares.length === 0 ? (
          <SoftCard className="flex flex-col items-center justify-center py-32 border-dashed border-2 border-surface0 bg-transparent shadow-none opacity-50">
            <Share2 size={64} className="text-surface2 mb-4 opacity-20" />
            <p className="text-overlay1 font-bold">Aucun partage actif</p>
          </SoftCard>
        ) : (
          shares.map((share, i) => {
            const isLink = share.type === 'link';
            return (
              <SoftCard key={i} className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 group transition-all py-8 bg-white shadow-sm border border-surface0/50">
                <div className="flex items-center gap-7">
                  <div className={cn(
                    "w-16 h-16 rounded-[24px] flex items-center justify-center shadow-lg transition-all",
                    isLink ? "bg-mauve/5 text-mauve" : "bg-blue/5 text-blue"
                  )}>
                    {isLink ? <LinkIcon size={28} /> : <User size={28} />}
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="font-black text-xl tracking-tighter truncate max-w-md flex items-center gap-2 text-text">
                        <FileText size={18} className="opacity-20" />
                        {share.filename}
                      </h4>
                      <AroChip 
                        label={isLink ? "Lien Public" : "Privé"} 
                        color={isLink ? "mauve" : "blue"} 
                      />
                      {share.is_active === false && <AroChip label="Inactif" color="red" />}
                    </div>
                    <div className="flex flex-wrap items-center gap-6 text-sm text-overlay1 font-medium">
                      <span className="flex items-center gap-2">
                        <ShieldCheck size={14} className="text-green opacity-60" />
                        Par : <strong className="text-text font-black tracking-tight">{share.owner}</strong>
                      </span>
                      <span className="flex items-center gap-2">
                        <ExternalLink size={14} className="opacity-40" />
                        Pour : <strong className={cn("font-black tracking-tight", isLink ? "text-mauve" : "text-text")}>{share.grantee}</strong>
                      </span>
                      <span className="flex items-center gap-1.5 opacity-60">
                        <Calendar size={14} /> 
                        {share.expires_at ? `Expire : ${new Date(share.expires_at).toLocaleDateString()}` : 'Illimité'}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 self-end lg:self-center">
                  <div className="flex flex-col items-end mr-4">
                     <p className="text-[10px] font-black uppercase tracking-widest text-overlay1 opacity-40 mb-1">Permissions</p>
                     <div className="flex gap-1">
                        <span className={cn("px-2 py-0.5 rounded text-[9px] font-black", share.can_read ? "bg-green/10 text-green" : "bg-red/10 text-red")}>READ</span>
                        <span className={cn("px-2 py-0.5 rounded text-[9px] font-black", share.can_write ? "bg-peach/10 text-peach" : "bg-red/10 text-red")}>WRITE</span>
                     </div>
                  </div>
                  <button 
                    onClick={() => handleRevoke(share)}
                    className="w-14 h-14 flex items-center justify-center bg-white text-overlay1 hover:text-red hover:bg-red/5 rounded-2xl transition-all active:scale-90 border border-surface0 shadow-sm"
                    title="Révoquer"
                  >
                    <Trash2 size={24} />
                  </button>
                </div>
              </SoftCard>
            );
          })
        )}
      </div>
    </div>
  );
};
