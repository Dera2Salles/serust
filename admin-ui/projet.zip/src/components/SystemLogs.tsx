import React, { useState, useEffect, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { ScrollText, RefreshCcw, Terminal } from 'lucide-react';
import { cn } from './OneUI';

export const SystemLogs: React.FC = () => {
  const [logs, setLogs] = useState<string[]>([]);
  const [autoScroll, setAutoScroll] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  const fetchLogs = async () => {
    try {
      const logContent = await invoke<string>('read_server_logs');
      setLogs(logContent.split('\n'));
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchLogs();
    const timer = setInterval(fetchLogs, 3000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  return (
    <div className="p-10 h-full flex flex-col space-y-6 bg-transparent">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 px-2">
        <div>
          <h2 className="text-4xl font-black text-text tracking-tighter">Logs <span className="text-blue">Serveur</span></h2>
          <p className="text-subtext0 font-bold text-xs uppercase tracking-[0.2em] opacity-60">Sortie temps réel du backend Kajy</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setAutoScroll(!autoScroll)}
            className={cn(
              "px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest border-2 transition-all active:scale-95 shadow-sm",
              autoScroll ? "bg-blue/5 border-blue/20 text-blue" : "bg-base border-surface1 text-subtext0 opacity-70"
            )}
          >
            Défilement: {autoScroll ? 'AUTO' : 'MANUEL'}
          </button>
          <button 
            onClick={fetchLogs}
            className="p-3 bg-base text-subtext0 rounded-full hover:bg-surface0 transition-all active:scale-90 border border-surface0 shadow-sm"
          >
            <RefreshCcw size={18} />
          </button>
        </div>
      </header>

      <div className="flex-1 bg-base rounded-[32px] border border-surface0 overflow-hidden flex flex-col shadow-md">
        <div className="bg-crust/50 px-6 py-4 border-b border-surface0 flex items-center justify-between">
            <div className="flex items-center gap-3">
                <Terminal size={14} className="text-blue" />
                <span className="text-[10px] font-black text-text uppercase tracking-widest">kajy_server.log</span>
            </div>
            <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green animate-pulse" />
                <span className="text-[9px] font-black text-subtext0 uppercase tracking-widest opacity-60">Live Stream</span>
            </div>
        </div>
        <div 
          ref={scrollRef}
          className="flex-1 p-6 overflow-y-auto font-mono text-[13px] space-y-1 selection:bg-blue/10 no-scrollbar"
        >
          {logs.map((line, i) => {
            if (!line.trim()) return null;
            let color = 'text-subtext0';
            let bgColor = 'transparent';
            
            if (line.includes('INFO')) color = 'text-blue';
            if (line.includes('WARN')) { color = 'text-yellow-700'; bgColor = 'bg-yellow-50/30'; }
            if (line.includes('ERROR')) { color = 'text-red-700'; bgColor = 'bg-red-50/30'; }
            if (line.includes('DEBUG')) color = 'text-overlay1 opacity-60';

            return (
              <div key={i} className={cn("px-4 py-1.5 rounded-xl transition-all border border-transparent hover:border-surface0 hover:bg-crust/30", color, bgColor)}>
                <span className="opacity-30 mr-5 select-none inline-block w-8 text-right font-bold text-[11px]">{i + 1}</span>
                {line}
              </div>
            );
          })}
          {logs.filter(l => l.trim()).length === 0 && (
            <div className="h-full flex flex-col items-center justify-center opacity-10 select-none py-32">
              <ScrollText size={80} className="mb-6" />
              <p className="font-sans font-black text-2xl text-center tracking-tighter uppercase text-text">Aucun flux de données</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
