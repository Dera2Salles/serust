import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Utility for Tailwind class merging.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * SoftCard - Radius 32px, white background, very subtle border.
 * Matches Flutter's SoftCard in light mode.
 */
interface SoftCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

export const SoftCard = ({ children, className, ...props }: SoftCardProps) => (
  <div 
    className={cn("oneui-card", className)}
    {...props}
  >
    {children}
  </div>
);

// Alias for backwards compatibility
export const Card = SoftCard;

/**
 * Header - Large high-contrast tracking-tight titles.
 */
interface HeaderProps {
  title: string;
  subtitle?: string;
  className?: string;
}

export const Header = ({ title, subtitle, className }: HeaderProps) => (
  <div className={cn("oneui-header", className)}>
    <h1 className="text-5xl font-black tracking-tighter mb-4 text-text leading-tight">{title}</h1>
    {subtitle && <p className="text-overlay1 text-lg font-bold tracking-tight opacity-70 uppercase tracking-widest text-xs">{subtitle}</p>}
  </div>
);

/**
 * Button - Pill-shaped with subtle shadows.
 */
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  icon?: React.ReactNode;
}

export const Button = ({ variant = 'primary', icon, className, children, ...props }: ButtonProps) => {
  const variantClasses = {
    primary: 'oneui-button-primary',
    secondary: 'bg-surface0 text-text hover:bg-surface1 px-8 py-3.5 rounded-full font-bold active:scale-95 transition-all shadow-sm',
    outline: 'bg-transparent border-2 border-surface1 text-overlay1 hover:border-blue hover:text-blue px-8 py-3.5 rounded-full font-bold active:scale-95 transition-all'
  };

  return (
    <button 
      className={cn(variantClasses[variant], className)}
      {...props}
    >
      {icon && <span className="inline-flex flex-shrink-0">{icon}</span>}
      {children}
    </button>
  );
};

/**
 * ModernTextField - Radius 24px, subtle inner shadow and focus ring.
 */
interface TextFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  prefixIcon?: React.ReactNode;
}

export const ModernTextField = ({ label, prefixIcon, className, ...props }: TextFieldProps) => (
  <div className="flex flex-col gap-2 w-full">
    {label && (
      <label className="text-[10px] font-black tracking-[0.2em] text-overlay1 px-2 uppercase opacity-60">
        {label}
      </label>
    )}
    <div className="relative group">
      {prefixIcon && (
        <div className="absolute left-6 top-1/2 -translate-y-1/2 text-overlay1 transition-colors group-focus-within:text-blue">
          {prefixIcon}
        </div>
      )}
      <input 
        className={cn(
          "w-full bg-white border border-surface0 rounded-[20px] py-4 pr-6 text-text font-bold placeholder:text-surface2 transition-all outline-none shadow-sm",
          prefixIcon ? "pl-14" : "pl-6",
          "focus:border-blue focus:shadow-blue/5",
          className
        )}
        {...props}
      />
    </div>
  </div>
);

/**
 * AroChip - High-contrast pill badges.
 */
interface AroChipProps {
  label: string;
  color?: string;
  className?: string;
}

export const AroChip = ({ label, color = 'blue', className }: AroChipProps) => {
  const colorClasses: Record<string, string> = {
    blue: 'bg-blue/5 text-blue border-blue/10',
    green: 'bg-green/5 text-green border-green/10',
    mauve: 'bg-mauve/5 text-mauve border-mauve/10',
    peach: 'bg-peach/5 text-peach border-peach/10',
    yellow: 'bg-yellow/5 text-yellow border-yellow/10',
    red: 'bg-red/5 text-red border-red/10',
    overlay2: 'bg-surface0 text-overlay1 border-surface1',
  };

  return (
    <div className={cn(
      "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border transition-all",
      colorClasses[color] || colorClasses.blue,
      className
    )}>
      {label}
    </div>
  );
};

/**
 * AroIconButton - Circular/Square-rounded action buttons.
 */
interface AroIconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: React.ReactNode;
}

export const AroIconButton = ({ icon, className, ...props }: AroIconButtonProps) => (
  <button 
    className={cn(
      "w-12 h-12 flex items-center justify-center bg-white border border-surface0 rounded-2xl text-text hover:bg-surface0 active:scale-90 transition-all shadow-sm",
      className
    )}
    {...props}
  >
    {icon}
  </button>
);
