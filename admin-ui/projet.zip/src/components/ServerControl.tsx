import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { Play, Square, RefreshCcw, HardDrive, Cpu, MemoryStick, Terminal, Activity, ShieldAlert } from 'lucide-react';
import { Header, SoftCard, cn } from './OneUI';

interface SystemInfo {
  total_disk: number;
  used_disk: number;
  os_name: string;
  cpu_usage: number;
  memory_usage: number;
}

export const ServerControl: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [sysInfo, setSysInfo] = useState<SystemInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const checkStatus = async () => {
    try {
      const status = await invoke<boolean>('get_server_status');
      setIsRunning(status);
    } catch (e) {
      console.error("Status check failed:", e);
    }
  };

  const fetchSysInfo = async () => {
    try {
      const info = await invoke<SystemInfo>('get_system_info');
      setSysInfo(info);
    } catch (e) {
      console.error("Sysinfo fetch failed:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const init = async () => {
        setLoading(true);
        await Promise.all([checkStatus(), fetchSysInfo()]);
    };
    init();
    
    const timer = setInterval(() => {
      checkStatus();
      fetchSysInfo();
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const handleStart = async () => {
    setActionLoading(true);
    setError(null);
    try {
      await invoke('start_server');
      setIsRunning(true);
    } catch (e: any) {
      setError(e.toString());
    } finally {
      setActionLoading(false);
    }
  };

  const handleStop = async () => {
    setActionLoading(true);
    setError(null);
    try {
      await invoke('stop_server');
      setIsRunning(false);
    } catch (e: any) {
      setError(e.toString());
    } finally {
      setActionLoading(false);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let val = bytes;
    let unitIndex = 0;
    while (val > 1024 && unitIndex < units.length - 1) {
      val /= 1024;
      unitIndex++;
    }
    return `${val.toFixed(1)} ${units[unitIndex]}`;
  };

  if (loading && !sysInfo) return (
    <div className="flex items-center justify-center h-full bg-transparent">
      <div className="w-12 h-12 border-4 border-blue/20 border-t-blue rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="flex flex-col w-full min-h-full bg-transparent pb-20">
      <Header 
        title="Contrôle Système" 
        subtitle="Cycle de vie du serveur et surveillance des ressources hôte" 
      />

      <div className="px-10 mb-10">
        <SoftCard className={cn(
          "flex flex-col md:flex-row items-center justify-between gap-8 p-10 border-2 transition-all shadow-xl bg-base",
          isRunning ? "border-green/20" : "border-red/20"
        )}>
          <div className="flex items-center gap-8">
            <div className={cn(
              "w-20 h-20 rounded-[32px] flex items-center justify-center shadow-2xl transition-transform duration-500 hover:rotate-12",
              isRunning ? "bg-green text-white shadow-green/30" : "bg-red text-white shadow-red/30"
            )}>
              <Terminal size={36} />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h4 className="font-black text-3xl tracking-tighter text-text">Processus Serveur</h4>
                <div className={cn(
                    "px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                    isRunning ? "bg-green/10 text-green" : "bg-red/10 text-red"
                )}>
                    {isRunning ? 'Actif' : 'Inactif'}
                </div>
              </div>
              <p className="text-sm font-bold text-subtext0 opacity-60">Gestionnaire de processus binaire MCP via Rust/Tauri</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
                onClick={isRunning ? handleStop : handleStart}
                disabled={actionLoading}
                className={cn(
                "flex items-center gap-4 px-12 py-5 rounded-full font-black text-xl transition-all active:scale-95 shadow-2xl disabled:opacity-50",
                isRunning 
                    ? "bg-red text-white shadow-red/20 hover:brightness-110" 
                    : "bg-green text-white shadow-green/20 hover:brightness-110"
                )}
            >
                {actionLoading ? <RefreshCcw size={24} className="animate-spin" /> : isRunning ? <Square size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" />}
                {isRunning ? 'Arrêter' : 'Démarrer'}
            </button>
            
            <button 
                onClick={() => { checkStatus(); fetchSysInfo(); }} 
                className="p-5 bg-crust text-overlay1 rounded-full hover:bg-surface0 transition-all active:scale-90 border border-surface0 shadow-md"
            >
                <RefreshCcw size={28} />
            </button>
          </div>
        </SoftCard>
      </div>

      {error && (
        <div className="px-10 mb-10">
            <div className="bg-red/5 border-2 border-red/10 text-red px-10 py-6 rounded-[32px] flex items-center gap-5 animate-in slide-in-from-top-4 duration-500 shadow-lg">
                <ShieldAlert size={32} />
                <div>
                    <p className="font-black text-lg tracking-tight">Erreur d'exécution</p>
                    <p className="text-sm font-bold opacity-70">{error}</p>
                </div>
            </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 px-10">
        <SoftCard className="bg-base p-10 group relative overflow-hidden">
          <div className="w-16 h-16 bg-blue/5 rounded-3xl flex items-center justify-center text-blue mb-10 transition-transform group-hover:scale-110 group-hover:rotate-6 duration-500 shadow-sm">
            <HardDrive size={32} />
          </div>
          <h3 className="text-xs font-black uppercase tracking-[0.2em] text-overlay1 mb-4 opacity-50">Espace Disque Hôte</h3>
          {sysInfo ? (
            <div>
              <p className="text-4xl font-black text-text tabular-nums tracking-tighter mb-6">
                {formatSize(sysInfo.used_disk)} <span className="text-lg text-subtext0 opacity-40 font-black">/ {formatSize(sysInfo.total_disk)}</span>
              </p>
              <div className="w-full h-4 bg-crust rounded-full overflow-hidden shadow-inner border border-surface0/30">
                <div 
                  className={cn(
                      "h-full transition-all duration-1000 ease-out",
                      (sysInfo.used_disk / sysInfo.total_disk) > 0.9 ? "bg-red" : "bg-blue"
                  )} 
                  style={{ width: `${(sysInfo.used_disk / sysInfo.total_disk) * 100}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="animate-pulse space-y-4">
                <div className="h-10 bg-crust rounded-2xl w-3/4" />
                <div className="h-4 bg-crust rounded-full w-full" />
            </div>
          )}
        </SoftCard>

        <SoftCard className="bg-base p-10 group relative overflow-hidden">
          <div className="w-16 h-16 bg-mauve/5 rounded-3xl flex items-center justify-center text-mauve mb-10 transition-transform group-hover:scale-110 group-hover:-rotate-6 duration-500 shadow-sm">
            <Cpu size={32} />
          </div>
          <h3 className="text-xs font-black uppercase tracking-[0.2em] text-overlay1 mb-4 opacity-50">Charge Processeur</h3>
          {sysInfo ? (
            <div>
              <p className="text-4xl font-black text-text tabular-nums tracking-tighter mb-6">
                {sysInfo.cpu_usage.toFixed(1)}%
              </p>
              <div className="w-full h-4 bg-crust rounded-full overflow-hidden shadow-inner border border-surface0/30">
                <div 
                  className={cn(
                    "h-full transition-all duration-1000 ease-out",
                    sysInfo.cpu_usage > 80 ? "bg-red" : "bg-mauve"
                  )} 
                  style={{ width: `${sysInfo.cpu_usage}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="animate-pulse space-y-4">
                <div className="h-10 bg-crust rounded-2xl w-1/2" />
                <div className="h-4 bg-crust rounded-full w-full" />
            </div>
          )}
        </SoftCard>

        <SoftCard className="bg-base p-10 group relative overflow-hidden">
          <div className="w-16 h-16 bg-green/5 rounded-3xl flex items-center justify-center text-green mb-10 transition-transform group-hover:scale-110 duration-500 shadow-sm">
            <MemoryStick size={32} />
          </div>
          <h3 className="text-xs font-black uppercase tracking-[0.2em] text-overlay1 mb-4 opacity-50">Utilisation RAM</h3>
          {sysInfo ? (
            <div className="space-y-6">
              <p className="text-4xl font-black text-text tabular-nums tracking-tighter">
                {formatSize(sysInfo.memory_usage)}
              </p>
              <div className="flex items-center gap-3 px-5 py-3 bg-crust rounded-2xl border border-surface0/50 w-fit">
                  <Activity size={16} className="text-green" />
                  <span className="text-[10px] font-black text-text uppercase tracking-widest">{sysInfo.os_name}</span>
              </div>
            </div>
          ) : (
            <div className="animate-pulse space-y-4">
                <div className="h-10 bg-crust rounded-2xl w-2/3" />
                <div className="h-10 bg-crust rounded-2xl w-1/2" />
            </div>
          )}
        </SoftCard>
      </div>
    </div>
  );
};
