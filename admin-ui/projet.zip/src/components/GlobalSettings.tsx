import React, { useState, useEffect } from 'react';
import { Header, SoftCard, cn, ModernTextField } from './OneUI';
import { Settings, Shield, Lock, Bell, Globe, Save, RefreshCcw, AlertTriangle } from 'lucide-react';
import { invoke } from '@tauri-apps/api/core';

interface GlobalSettingsData {
  allow_registration: boolean;
  maintenance_mode: boolean;
  max_user_quota_gb: number;
  server_name: string;
}

export const GlobalSettings: React.FC = () => {
  const [settings, setSettings] = useState<GlobalSettingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ text: string, type: 'success' | 'error' } | null>(null);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const data = await invoke<GlobalSettingsData>('get_global_settings');
      setSettings(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSave = async () => {
    if (!settings) return;
    setSaving(true);
    setMessage(null);
    try {
      await invoke('save_global_settings', { settings });
      setMessage({ text: 'Paramètres enregistrés avec succès', type: 'success' });
    } catch (e) {
      setMessage({ text: `Erreur: ${e}`, type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full bg-transparent">
        <div className="w-12 h-12 border-4 border-blue/20 border-t-blue rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex flex-col w-full min-h-full bg-transparent pb-20">
      <Header 
        title="Paramètres" 
        subtitle="Configuration système et politiques de sécurité Kajy" 
      />

      <div className="px-10 max-w-5xl mx-auto w-full space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div className="md:col-span-2 space-y-8">
            <SoftCard className="p-10 space-y-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-blue/5 text-blue rounded-2xl flex items-center justify-center">
                  <Globe size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-black tracking-tighter">Identité Plateforme</h3>
                  <p className="text-xs font-bold text-overlay1 uppercase tracking-widest opacity-60">Visibilité publique du serveur</p>
                </div>
              </div>
              
              <ModernTextField 
                label="Nom de l'instance" 
                value={settings?.server_name || ''} 
                onChange={(v) => settings && setSettings({...settings, server_name: v})}
                placeholder="ex: Kajy Cloud Madagascar"
              />

              <div className="pt-4 space-y-4">
                <div className="flex items-center justify-between p-6 bg-crust rounded-[24px] border border-surface0">
                   <div className="flex items-center gap-4">
                      <Lock size={20} className="text-blue" />
                      <div>
                         <p className="font-black text-text">Inscriptions Ouvertes</p>
                         <p className="text-[10px] font-bold text-overlay1 uppercase tracking-widest">Autoriser les nouveaux comptes</p>
                      </div>
                   </div>
                   <button 
                    onClick={() => settings && setSettings({...settings, allow_registration: !settings.allow_registration})}
                    className={cn(
                      "w-16 h-8 rounded-full transition-all relative px-1 flex items-center shadow-inner",
                      settings?.allow_registration ? "bg-green" : "bg-surface1"
                    )}
                   >
                     <div className={cn("w-6 h-6 bg-white rounded-full shadow-md transition-all", settings?.allow_registration ? "translate-x-8" : "translate-x-0")} />
                   </button>
                </div>

                <div className={cn(
                  "flex items-center justify-between p-6 rounded-[24px] border transition-all",
                  settings?.maintenance_mode ? "bg-red/5 border-red/20" : "bg-crust border-surface0"
                )}>
                   <div className="flex items-center gap-4">
                      <AlertTriangle size={20} className={settings?.maintenance_mode ? "text-red" : "text-overlay1"} />
                      <div>
                         <p className={cn("font-black", settings?.maintenance_mode ? "text-red" : "text-text")}>Mode Maintenance</p>
                         <p className="text-[10px] font-bold text-overlay1 uppercase tracking-widest">Bloquer tous les accès client</p>
                      </div>
                   </div>
                   <button 
                    onClick={() => settings && setSettings({...settings, maintenance_mode: !settings.maintenance_mode})}
                    className={cn(
                      "w-16 h-8 rounded-full transition-all relative px-1 flex items-center shadow-inner",
                      settings?.maintenance_mode ? "bg-red" : "bg-surface1"
                    )}
                   >
                     <div className={cn("w-6 h-6 bg-white rounded-full shadow-md transition-all", settings?.maintenance_mode ? "translate-x-8" : "translate-x-0")} />
                   </button>
                </div>
              </div>
            </SoftCard>

            <SoftCard className="p-10 space-y-6">
              <div className="flex items-center gap-4 mb-2">
                <div className="w-12 h-12 bg-peach/5 text-peach rounded-2xl flex items-center justify-center">
                  <Shield size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-black tracking-tighter">Limites de Ressources</h3>
                  <p className="text-xs font-bold text-overlay1 uppercase tracking-widest opacity-60">Quotas par défaut</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-[10px] font-black text-overlay1 uppercase tracking-widest px-1">Quota Maximum par Utilisateur (GB)</label>
                <input 
                  type="number" 
                  className="w-full px-6 py-4 bg-crust rounded-[20px] border border-surface0 focus:border-blue outline-none transition-all font-black"
                  value={settings?.max_user_quota_gb || 0}
                  onChange={(e) => settings && setSettings({...settings, max_user_quota_gb: Number(e.target.value)})}
                />
              </div>
            </SoftCard>
          </div>

          <div className="space-y-6">
            <SoftCard className="p-8 bg-blue text-white shadow-xl shadow-blue/20">
              <h4 className="text-xl font-black tracking-tighter mb-4 flex items-center gap-2">
                <Save size={20} /> Actions
              </h4>
              <p className="text-sm font-medium opacity-80 mb-8 leading-relaxed">Les modifications sont appliquées instantanément sur tous les nœuds du serveur.</p>
              
              <button 
                onClick={handleSave}
                disabled={saving}
                className="w-full py-4 bg-white text-blue rounded-2xl font-black transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-3"
              >
                {saving ? <RefreshCcw className="animate-spin" size={20} /> : <Save size={20} />}
                {saving ? 'Enregistrement...' : 'Sauvegarder'}
              </button>
              
              {message && (
                <div className={cn(
                  "mt-4 p-4 rounded-xl text-[10px] font-black uppercase tracking-widest text-center animate-in slide-in-from-top-2",
                  message.type === 'success' ? "bg-white/20" : "bg-red/20"
                )}>
                  {message.text}
                </div>
              )}
            </SoftCard>

            <SoftCard className="p-8 bg-base border border-surface0 border-dashed">
               <h4 className="text-sm font-black text-text uppercase tracking-widest mb-4">Aide</h4>
               <p className="text-xs font-medium text-overlay1 leading-loose">
                 Le mode maintenance permet de couper proprement les services avant une mise à jour système.
               </p>
            </SoftCard>
          </div>
        </div>
      </div>
    </div>
  );
};
