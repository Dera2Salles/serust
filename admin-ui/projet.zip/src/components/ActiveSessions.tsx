import React, { useState, useEffect } from 'react';
import { Header, SoftCard, AroChip, cn } from './OneUI';
import { Activity, Clock, Globe, Shield, Terminal, ZapOff } from 'lucide-react';

interface Session {
  peer_addr: String;
  connected_at: string;
  last_command: string | null;
  username: string | null;
}

export const ActiveSessions = () => {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchStatus = async () => {
    try {
      const response = await fetch('http://localhost:8081/api/server/status');
      const data = await response.json();
      setSessions(data.sessions || []);
    } catch (err) {
      console.error("Failed to fetch server status:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col w-full min-h-full bg-transparent pb-20">
      <Header 
        title="Connexions" 
        subtitle="Surveillance en temps réel des accès réseau" 
      />

      <div className="px-10 grid grid-cols-1 gap-5">
        {loading && sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 opacity-40">
             <div className="w-10 h-10 border-4 border-blue/20 border-t-blue rounded-full animate-spin mb-4" />
             <p className="text-overlay1 font-black uppercase text-[10px] tracking-widest">Écoute du port 8081...</p>
          </div>
        ) : sessions.length === 0 ? (
          <SoftCard className="flex flex-col items-center justify-center py-32 border-dashed border-2 border-surface0 bg-transparent shadow-none opacity-50">
            <ZapOff size={64} className="text-surface2 mb-4 opacity-10" />
            <h4 className="text-xl font-black text-text mb-1 tracking-tight">Aucune activité réseau</h4>
            <p className="text-sm font-medium text-overlay1">Le serveur est en attente de connexions.</p>
          </SoftCard>
        ) : (
          sessions.map((session, i) => (
            <SoftCard key={i} className="flex items-center justify-between group transition-all py-8 bg-white shadow-sm border border-surface0/50">
              <div className="flex items-center gap-7">
                <div className={cn(
                  "w-16 h-16 rounded-[24px] flex items-center justify-center font-black text-2xl shadow-lg transition-transform group-hover:scale-105",
                  session.username ? "bg-blue text-white shadow-blue/20" : "bg-mantle text-overlay1 border border-surface0"
                )}>
                  {session.username ? session.username.charAt(0).toUpperCase() : <Globe size={28} className="opacity-40" />}
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="font-black text-xl tracking-tighter text-text">{session.username || 'Client Anonyme'}</h4>
                    {session.username ? (
                      <AroChip label="Authentifié" color="blue" />
                    ) : (
                      <AroChip label="Non authentifié" color="red" />
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-6 text-sm text-overlay1 font-medium">
                    <span className="flex items-center gap-2 bg-mantle px-4 py-1.5 rounded-full border border-surface0 shadow-inner">
                      <Terminal size={14} className="text-blue" />
                      <span className="font-mono text-xs font-bold">{session.peer_addr}</span>
                    </span>
                    <span className="flex items-center gap-2 opacity-60">
                      <Clock size={14} /> 
                      Depuis {new Date(session.connected_at).toLocaleTimeString()}
                    </span>
                    {session.last_command && (
                      <span className="flex items-center gap-2">
                        <Activity size={14} className="text-blue opacity-50" /> 
                        Action : <span className="font-black text-text tracking-tight uppercase text-xs bg-blue/5 px-2 py-0.5 rounded">{session.last_command}</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <button className="px-6 py-3 bg-red/5 text-red hover:bg-red hover:text-white font-black text-[10px] uppercase tracking-widest rounded-full transition-all active:scale-95 border border-red/10 shadow-sm">
                  Kick Session
                </button>
              </div>
            </SoftCard>
          ))
        )}
      </div>
    </div>
  );
};
