import React, { useState, useEffect } from 'react';
import { Header, SoftCard, cn } from './OneUI';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area
} from 'recharts';
import { Activity, HardDrive, Users, ArrowUpRight, ArrowDownRight, ServerOff, CheckCircle2, Play } from 'lucide-react';
import { invoke } from '@tauri-apps/api/core';

interface SummaryData {
  total_accesses: number;
  total_bytes_transferred: number;
  unique_files_accessed: number;
  unique_ips: number;
  bandwidth_by_day: any[];
  recent_activity: any[];
}

export const AdminDashboard = () => {
  const [data, setData] = useState<SummaryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isRunning, setIsRunning] = useState(false);

  const fetchData = async () => {
    try {
      const status = await invoke<boolean>('get_server_status');
      setIsRunning(status);
      
      if (status) {
        const response = await fetch('http://localhost:8081/api/analytics/summary?username=admin_dev');
        if (response.ok) {
          const json = await response.json();
          setData(json);
        }
      }
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const timer = setInterval(fetchData, 5000);
    return () => clearInterval(timer);
  }, []);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (loading) return (
    <div className="flex items-center justify-center h-full bg-transparent">
      <div className="w-12 h-12 border-4 border-blue/20 border-t-blue rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="flex flex-col w-full min-h-full bg-transparent pb-20">
      <Header 
        title="Console Admin" 
        subtitle="Vue d'ensemble du serveur Kajy" 
      />

      <div className="px-10 mb-10">
        <SoftCard className={cn(
          "flex items-center justify-between p-8 border-2 transition-all shadow-md",
          isRunning ? "border-green/20 bg-base" : "border-red/20 bg-base"
        )}>
          <div className="flex items-center gap-6">
            <div className={cn(
              "w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg",
              isRunning ? "bg-green text-white shadow-green/20" : "bg-red text-white shadow-red/20"
            )}>
              {isRunning ? <CheckCircle2 size={28} /> : <ServerOff size={28} />}
            </div>
            <div>
              <h4 className="font-black text-2xl tracking-tighter">Serveur {isRunning ? 'En ligne' : 'Hors ligne'}</h4>
              <p className="text-[10px] font-black text-overlay1 uppercase tracking-widest opacity-60">Status MCP Realtime</p>
            </div>
          </div>
          
          {!isRunning && (
            <button 
              onClick={async () => {
                try { await invoke('start_server'); fetchData(); } catch(e) { alert(e); }
              }}
              className="flex items-center gap-3 px-10 py-4 bg-red text-white rounded-full font-black transition-all hover:brightness-110 active:scale-95 shadow-xl shadow-red/20"
            >
              <Play size={20} fill="currentColor" />
              Démarrer le Serveur
            </button>
          )}
        </SoftCard>
      </div>

      <div className="px-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Accès Totaux', val: data?.total_accesses || 0, icon: Activity, color: 'blue' },
          { label: 'Trafic Global', val: formatBytes(data?.total_bytes_transferred || 0), icon: ArrowUpRight, color: 'text' },
          { label: 'Fichiers Uniques', val: data?.unique_files_accessed || 0, icon: HardDrive, color: 'green' },
          { label: 'Visiteurs (IPs)', val: data?.unique_ips || 0, icon: Users, color: 'peach' }
        ].map((stat, i) => (
          <SoftCard key={i} className="flex items-center gap-5 group hover:scale-[1.02] active:scale-[0.98]">
            <div className={cn(
              "w-16 h-16 rounded-2xl flex items-center justify-center transition-transform group-hover:rotate-6 shadow-sm",
              stat.color === 'blue' ? 'bg-blue/5 text-blue' :
              stat.color === 'green' ? 'bg-green/5 text-green' :
              stat.color === 'peach' ? 'bg-peach/5 text-peach' : 'bg-surface0/50 text-text'
            )}>
              <stat.icon size={32} />
            </div>
            <div>
              <p className="text-overlay1 text-[10px] font-black tracking-widest uppercase opacity-60 mb-1">{stat.label}</p>
              <p className="text-3xl font-black tracking-tighter text-text">{stat.val}</p>
            </div>
          </SoftCard>
        ))}
      </div>

      <div className="px-10 mt-10 grid grid-cols-1 lg:grid-cols-3 gap-10">
        <SoftCard className="lg:col-span-2 p-8 overflow-hidden">
          <div className="flex items-center justify-between mb-10 px-2">
            <h3 className="text-2xl font-black tracking-tighter">Flux Réseau</h3>
            <div className="px-5 py-2 bg-crust rounded-full text-[10px] font-black text-overlay1 border border-surface0 uppercase tracking-widest">30 Derniers Jours</div>
          </div>
          <div className="h-[380px] w-full">
            {!isRunning ? (
               <div className="h-full flex flex-col items-center justify-center opacity-10">
                  <ServerOff size={80} className="mb-6" />
                  <p className="font-black tracking-tighter text-2xl uppercase">Statistiques Indisponibles</p>
               </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data?.bandwidth_by_day || []}>
                  <defs>
                    <linearGradient id="colorBytes" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#1e66f5" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#1e66f5" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="4 4" stroke="#ccd0da" vertical={false} />
                  <XAxis dataKey="date" stroke="#9ca0b0" fontSize={11} fontWeight={900} tickLine={false} axisLine={false} dy={15} />
                  <YAxis stroke="#9ca0b0" fontSize={11} fontWeight={900} tickFormatter={formatBytes} tickLine={false} axisLine={false} dx={-10} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #ccd0da', borderRadius: '24px', boxShadow: '0 20px 40px rgba(0,0,0,0.05)', padding: '15px' }}
                    itemStyle={{ color: '#1e66f5', fontWeight: 900, fontSize: '15px' }}
                    labelStyle={{ color: '#4c4f69', marginBottom: '6px', fontWeight: 900, fontSize: '11px', textTransform: 'uppercase', letterSpacing: '1px' }}
                    cursor={{ stroke: '#1e66f5', strokeWidth: 2, strokeDasharray: '4 4' }}
                  />
                  <Area type="monotone" dataKey="bytes_total" stroke="#1e66f5" strokeWidth={4} fillOpacity={1} fill="url(#colorBytes)" animationDuration={2000} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </SoftCard>

        <SoftCard className="p-8">
          <h3 className="text-2xl font-black tracking-tighter mb-8 px-2">Activités Récentes</h3>
          <div className="space-y-4">
            {isRunning && data?.recent_activity?.slice(0, 8).map((activity: any, i: number) => (
              <div key={i} className="flex items-center gap-4 group cursor-pointer hover:bg-crust/50 p-3 rounded-2xl transition-all border border-transparent hover:border-surface0">
                <div className={cn(
                  "w-11 h-11 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110 shadow-sm",
                  activity.action === 'read' ? 'bg-blue/5 text-blue' : 'bg-green/5 text-green'
                )}>
                  {activity.action === 'read' ? <ArrowDownRight size={20} /> : <ArrowUpRight size={20} />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-black text-text truncate group-hover:text-blue transition-colors">{activity.filename}</p>
                  <p className="text-[10px] text-overlay1 font-bold opacity-60 tracking-widest uppercase truncate">{activity.ip_address || 'Interne'} • {activity.action}</p>
                </div>
                <div className="text-[10px] font-black text-overlay1 bg-surface0/50 px-3 py-1.5 rounded-full border border-surface0/50 whitespace-nowrap">
                  {new Date(activity.accessed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            ))}
            {(!isRunning || !data?.recent_activity?.length) && (
              <div className="flex flex-col items-center justify-center py-20 opacity-20 text-center">
                <Activity size={48} className="mb-4" />
                <p className="text-sm font-black uppercase tracking-widest">Aucune donnée</p>
              </div>
            )}
          </div>
        </SoftCard>
      </div>
    </div>
  );
};
