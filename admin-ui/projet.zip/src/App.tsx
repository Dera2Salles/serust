import { useState } from 'react';
import { AdminDashboard } from './components/AdminDashboard';
import { UserManagement } from './components/UserManagement';
import { FileExplorer } from './components/FileExplorer';
import { ServerControl } from './components/ServerControl';
import { SystemLogs } from './components/SystemLogs';
import { DatabaseInspector } from './components/DatabaseInspector';
import { ActiveSessions } from './components/ActiveSessions';
import { ShareManagement } from './components/ShareManagement';
import { GlobalSettings } from './components/GlobalSettings';
import { LayoutDashboard, Users, FolderTree, Settings, Activity, Share2, ScrollText, Cpu, Database } from 'lucide-react';
import { cn } from './components/OneUI';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'system', label: 'System', icon: Cpu },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'sessions', label: 'Connections', icon: Activity },
    { id: 'shares', label: 'Shares', icon: Share2 },
    { id: 'files', label: 'Files', icon: FolderTree },
    { id: 'logs', label: 'Logs', icon: ScrollText },
    { id: 'database', label: 'Database', icon: Database },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="flex w-full h-screen bg-crust text-text overflow-hidden selection:bg-blue/10 selection:text-blue">
      {/* Side Navigation */}
      <aside className="w-24 md:w-72 flex flex-col bg-mantle border-r border-surface0/50 py-10 px-5 transition-all z-20">
        <div className="px-4 mb-14 hidden md:flex items-center gap-3">
          <div className="w-10 h-10 bg-blue rounded-xl flex items-center justify-center shadow-lg shadow-blue/20">
            <img src="/logo.png" alt="K" className="w-6 h-6 object-contain invert brightness-0" />
          </div>
          <h2 className="text-2xl font-black text-text tracking-tighter">Kajy <span className="text-blue">Admin</span></h2>
        </div>
        
        <nav className="flex-1 space-y-2 overflow-y-auto no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "w-full flex items-center gap-4 px-5 py-4 rounded-[24px] transition-all duration-300 group",
                  active 
                    ? "bg-blue text-white shadow-lg shadow-blue/20 translate-x-1" 
                    : "text-subtext0 hover:bg-surface0 hover:text-text"
                )}
              >
                <Icon size={22} className={cn("transition-transform group-active:scale-90", active && "stroke-[2.5px]")} />
                <span className={cn("hidden md:block font-bold tracking-tight text-sm", active && "text-white")}>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="mt-auto p-4 bg-base/50 backdrop-blur-sm rounded-[24px] hidden md:flex items-center gap-4 border border-surface0 shadow-sm">
          <div className="w-10 h-10 rounded-full bg-blue flex items-center justify-center text-white font-black text-lg shadow-inner">
            A
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-text truncate">Admin User</p>
            <p className="text-[10px] text-overlay1 font-black truncate uppercase tracking-widest opacity-60">Session Maître</p>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto overflow-x-hidden relative bg-crust">
        <div className="h-full w-full">
          {activeTab === 'dashboard' && <AdminDashboard />}
          {activeTab === 'system' && <ServerControl />}
          {activeTab === 'users' && <UserManagement />}
          {activeTab === 'sessions' && <ActiveSessions />}
          {activeTab === 'shares' && <ShareManagement />}
          {activeTab === 'files' && <FileExplorer />}
          {activeTab === 'logs' && <SystemLogs />}
          {activeTab === 'database' && <DatabaseInspector />}
          {activeTab === 'settings' && <GlobalSettings />}
        </div>
      </main>
    </div>
  );
}

export default App;
